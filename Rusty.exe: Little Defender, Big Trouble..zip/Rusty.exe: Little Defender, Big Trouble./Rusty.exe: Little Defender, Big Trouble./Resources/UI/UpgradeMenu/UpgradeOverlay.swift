// UpgradeOverlay.swift

import SpriteKit

class UpgradeOverlay: SKNode {
    var onDismiss: (() -> Void)?
    var onPurchase: ((StatType) -> Void)?

    private let background: SKSpriteNode
    private let weapon: WeaponInfo
    private let currentGems: Int

    init(for weapon: WeaponInfo, currentGems: Int) {
        self.weapon = weapon
        self.currentGems = currentGems

        background = SKSpriteNode(color: .darkGray, size: CGSize(width: 320, height: 420))
        background.zPosition = 100
        background.alpha = 0.95
        super.init()

        self.zPosition = 99
        self.isUserInteractionEnabled = true
        self.addChild(background)
        layoutContent()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func layoutContent() {
        let title = SKLabelNode(text: "Upgrade: \(weapon.name)")
        title.fontName = "AvenirNext-Bold"
        title.fontSize = 20
        title.position = CGPoint(x: 0, y: 170)
        addChild(title)

        var yOffset = 120
        for stat in StatType.allCases {
            if let upgradeLevels = weapon.upgrades[stat.rawValue], !upgradeLevels.isEmpty {
                let nextUpgrade = upgradeLevels.first
                let requirement = nextUpgrade?.requirement
                let label = SKLabelNode(text: "\(stat.rawValue.capitalized): +\(nextUpgrade?.value ?? 0) (\(requirement?.gems ?? 0) gems)")
                label.fontName = "AvenirNext-Regular"
                label.fontSize = 14
                label.position = CGPoint(x: 0, y: yOffset)
                label.name = "upgrade_\(stat.rawValue)"
                addChild(label)
                yOffset -= 30
            }
        }

        let buyGems = SKLabelNode(text: "Buy Gems")
        buyGems.name = "buy_gems"
        buyGems.fontName = "AvenirNext-Bold"
        buyGems.fontSize = 14
        buyGems.fontColor = .cyan
        buyGems.position = CGPoint(x: 0, y: -150)
        addChild(buyGems)

        let closeButton = SKLabelNode(text: "Close")
        closeButton.name = "close_overlay"
        closeButton.fontName = "AvenirNext-Bold"
        closeButton.fontSize = 14
        closeButton.fontColor = .orange
        closeButton.position = CGPoint(x: 0, y: -180)
        addChild(closeButton)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)

        for node in nodes(at: location) {
            guard let name = node.name else { continue }

            if name.starts(with: "upgrade_") {
                let statRaw = name.replacingOccurrences(of: "upgrade_", with: "")
                if let stat = StatType(rawValue: statRaw),
                   let upgrades = weapon.upgrades[statRaw], !upgrades.isEmpty,
                   let requirement = upgrades.first?.requirement,
                   (requirement.gems ?? 0) <= currentGems {
                    onPurchase?(stat)
                }
            } else if name == "close_overlay" {
                onDismiss?()
                self.removeFromParent()
            } else if name == "buy_gems" {
                print("Buy Gems tapped")
            }
        }
    }
}
