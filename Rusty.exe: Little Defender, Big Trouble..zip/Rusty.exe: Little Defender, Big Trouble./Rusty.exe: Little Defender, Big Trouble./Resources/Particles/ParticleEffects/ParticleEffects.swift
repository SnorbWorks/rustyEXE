import SpriteKit

class ParticleEffects {
    // MARK: - Shared Instance
    static let shared = ParticleEffects()
    
    // MARK: - Properties
    private var cachedEmitters: [String: SKEmitterNode] = [:]
    
    // MARK: - Effect Categories
    enum EffectCategory: String {
        case weapon
        case shield
        case patch
        case skin
        
        var directory: String {
            switch self {
            case .weapon: return "WeaponEffects"
            case .shield: return "ShieldEffects"
            case .patch: return "PatchEffects"
            case .skin: return "SkinEffects"
            }
        }
    }
    
    // MARK: - Effect Definitions
    struct EffectDefinition {
        let name: String
        let category: EffectCategory
        let baseColor: SKColor
        let particleScale: CGFloat
        let birthRate: CGFloat
        let lifetime: CGFloat
        let speed: CGFloat
        let alpha: CGFloat
        let blendMode: SKBlendMode
        let properties: [String: Any]
    }
    
    // MARK: - Weapon Effects
    private let weaponEffects: [String: EffectDefinition] = [
        "energyBolt": EffectDefinition(
            name: "energyBolt",
            category: .weapon,
            baseColor: .cyan,
            particleScale: 0.5,
            birthRate: 60,
            lifetime: 0.5,
            speed: 400,
            alpha: 0.8,
            blendMode: .add,
            properties: [
                "trail": true,
                "glow": true
            ]
        ),
        "plasmaBurst": EffectDefinition(
            name: "plasmaBurst",
            category: .weapon,
            baseColor: .red,
            particleScale: 1.0,
            birthRate: 100,
            lifetime: 0.3,
            speed: 300,
            alpha: 0.9,
            blendMode: .add,
            properties: [
                "explosion": true,
                "heat": true
            ]
        ),
        // Add more weapon effects...
    ]
    
    // MARK: - Shield Effects
    private let shieldEffects: [String: EffectDefinition] = [
        "energyRipple": EffectDefinition(
            name: "energyRipple",
            category: .shield,
            baseColor: .blue,
            particleScale: 1.5,
            birthRate: 40,
            lifetime: 1.0,
            speed: 100,
            alpha: 0.6,
            blendMode: .add,
            properties: [
                "ripple": true,
                "pulse": true
            ]
        ),
        "voidShield": EffectDefinition(
            name: "voidShield",
            category: .shield,
            baseColor: .purple,
            particleScale: 2.0,
            birthRate: 80,
            lifetime: 1.5,
            speed: 50,
            alpha: 0.7,
            blendMode: .add,
            properties: [
                "void": true,
                "absorption": true
            ]
        ),
        // Add more shield effects...
    ]
    
    // MARK: - Patch Effects
    private let patchEffects: [String: EffectDefinition] = [
        "rageMist": EffectDefinition(
            name: "rageMist",
            category: .patch,
            baseColor: .red,
            particleScale: 1.2,
            birthRate: 50,
            lifetime: 2.0,
            speed: 30,
            alpha: 0.5,
            blendMode: .add,
            properties: [
                "mist": true,
                "swirl": true
            ]
        ),
        "timeWarp": EffectDefinition(
            name: "timeWarp",
            category: .patch,
            baseColor: .green,
            particleScale: 1.8,
            birthRate: 70,
            lifetime: 1.2,
            speed: 80,
            alpha: 0.6,
            blendMode: .add,
            properties: [
                "distortion": true,
                "temporal": true
            ]
        ),
        // Add more patch effects...
    ]
    
    // MARK: - Skin Effects
    private let skinEffects: [String: EffectDefinition] = [
        "ghostTrail": EffectDefinition(
            name: "ghostTrail",
            category: .skin,
            baseColor: .white,
            particleScale: 1.0,
            birthRate: 30,
            lifetime: 0.8,
            speed: 0,
            alpha: 0.4,
            blendMode: .alpha,
            properties: [
                "fade": true,
                "trail": true
            ]
        ),
        "crystalAura": EffectDefinition(
            name: "crystalAura",
            category: .skin,
            baseColor: .cyan,
            particleScale: 0.8,
            birthRate: 45,
            lifetime: 1.5,
            speed: 20,
            alpha: 0.7,
            blendMode: .add,
            properties: [
                "sparkle": true,
                "rotate": true
            ]
        ),
        // Add more skin effects...
    ]
    
    // MARK: - Effect Creation
    func createEffect(_ name: String, category: EffectCategory) -> SKEmitterNode? {
        // Check cache first
        if let cachedEmitter = cachedEmitters[name] {
            return cachedEmitter.copy() as? SKEmitterNode
        }
        
        // Get effect definition
        let definition: EffectDefinition?
        switch category {
        case .weapon:
            definition = weaponEffects[name]
        case .shield:
            definition = shieldEffects[name]
        case .patch:
            definition = patchEffects[name]
        case .skin:
            definition = skinEffects[name]
        }
        
        guard let def = definition else { return nil }
        
        // Create emitter from file
        guard let emitter = SKEmitterNode(fileNamed: "\(category.directory)/\(name)") else {
            return nil
        }
        
        // Apply definition properties
        configureEmitter(emitter, with: def)
        
        // Cache the template
        cachedEmitters[name] = emitter.copy() as? SKEmitterNode
        
        return emitter
    }
    
    // MARK: - Emitter Configuration
    private func configureEmitter(_ emitter: SKEmitterNode, with definition: EffectDefinition) {
        emitter.particleColor = definition.baseColor
        emitter.particleScale = definition.particleScale
        emitter.particleBirthRate = definition.birthRate
        emitter.particleLifetime = definition.lifetime
        emitter.particleSpeed = definition.speed
        emitter.particleAlpha = definition.alpha
        emitter.particleBlendMode = definition.blendMode
        
        // Apply additional properties
        for (key, value) in definition.properties {
            switch key {
            case "trail":
                if value as? Bool == true {
                    emitter.particleAlphaSpeed = -0.5
                }
            case "glow":
                if value as? Bool == true {
                    emitter.particleColorBlendFactor = 0.8
                }
            case "explosion":
                if value as? Bool == true {
                    emitter.particleScaleSpeed = 1.0
                }
            // Add more property handlers
            default:
                break
            }
        }
    }
    
    // MARK: - Effect Modification
    func modifyEffect(_ emitter: SKEmitterNode, color: SKColor) {
        emitter.particleColor = color
    }
    
    func modifyEffect(_ emitter: SKEmitterNode, scale: CGFloat) {
        emitter.particleScale *= scale
    }
    
    func modifyEffect(_ emitter: SKEmitterNode, birthRate: CGFloat) {
        emitter.particleBirthRate = birthRate
    }
    
    // MARK: - Cleanup
    func clearCache() {
        cachedEmitters.removeAll()
    }
}

// MARK: - Effect Names
extension ParticleEffects {
    enum WeaponEffectName: String {
        case energyBolt
        case plasmaBurst
        case quantumRift
        case lightningArc
        case gravityWell
        case timeDistortion
        case plasmaBurst
        case droneTrail
    }
    
    enum ShieldEffectName: String {
        case energyRipple
        case shockwave
        case chronoShift
        case voidRift
        case mirrorShimmer
        case resonancePulse
        case vortexSpin
    }
    
    enum PatchEffectName: String {
        case rageMist
        case emergencyPower
        case overclockedSteam
        case adaptiveShimmer
    }
    
    enum SkinEffectName: String {
        case ghostTrail
        case crystalAura
        case dimensionalRift
        case starfall
    }
}

// MARK: - Usage Example
extension ParticleEffects {
    static func example() {
        let effects = ParticleEffects.shared
        
        // Create weapon effect
        if let energyBolt = effects.createEffect("energyBolt", category: .weapon) {
            // Modify effect
            effects.modifyEffect(energyBolt, color: .blue)
            effects.modifyEffect(energyBolt, scale: 1.5)
            
            // Add to scene
            // yourScene.addChild(energyBolt)
        }
    }
}
