import GameplayKit

class ShieldManager {
    // MARK: - Properties
    static let shared = ShieldManager()
    
    private var unlockedShields: Set<String> = ["basicBarrier"] // Start with basic barrier
    private var shields: [String: Shield] = [:]
    private var activeShields: [Shield] = []
    private let maxActiveShields = 2
    private var equippedShields: [Shield] = []
    private let maxEquippedShields = 3
    private let currencyManager = CurrencyManager.shared
    
    // MARK: - Initialization
    private init() {
        loadShieldsData()
        loadProgress()
        NotificationCenter.default.addObserver(self,
                                            selector: #selector(handleWaveEnd),
                                            name: .waveCompleted,
                                            object: nil)
    }
    
    private func loadShieldsData() {
        guard let url = Bundle.main.url(forResource: "shields", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
              let shieldsData = json["shields"] as? [String: [String: Any]] else {
            print("Failed to load shields data")
            return
        }
        
        for (shieldId, shieldData) in shieldsData {
            if let shield = createShield(id: shieldId, data: shieldData) {
                shields[shieldId] = shield
            }
        }
    }
    
    // MARK: - Shield Management
    func canUnlock(_ shieldId: String) -> Bool {
        guard let shield = shields[shieldId],
              !unlockedShields.contains(shieldId) else {
            return false
        }
        
        return currencyManager.canAfford(shield.getUnlockRequirement())
    }
    
    func unlockShield(_ shieldId: String) -> Bool {
        guard let shield = shields[shieldId],
              !unlockedShields.contains(shieldId) else {
            return false
        }
        
        if currencyManager.spend(shield.getUnlockRequirement()) {
            unlockedShields.insert(shieldId)
            NotificationCenter.default.post(
                name: .shieldUnlocked,
                object: nil,
                userInfo: ["shieldId": shieldId]
            )
            saveProgress()
            return true
        }
        
        NotificationCenter.default.post(name: .insufficientFunds, object: nil)
        return false
    }
    
    func equipShield(_ shieldId: String) -> Bool {
        guard unlockedShields.contains(shieldId),
              let shield = shields[shieldId],
              equippedShields.count < maxEquippedShields else {
            return false
        }
        
        equippedShields.append(shield)
        NotificationCenter.default.post(
            name: .shieldEquipped,
            object: nil,
            userInfo: ["shieldId": shieldId]
        )
        saveProgress()
        return true
    }
    
    func unequipShield(_ shieldId: String) -> Bool {
        guard let index = equippedShields.firstIndex(where: { $0.getId() == shieldId }) else {
            return false
        }
        
        equippedShields.remove(at: index)
        NotificationCenter.default.post(
            name: .shieldUnequipped,
            object: nil,
            userInfo: ["shieldId": shieldId]
        )
        saveProgress()
        return true
    }
    
    func deployShield(_ shieldId: String, at position: Vector2) -> Bool {
        guard let shield = equippedShields.first(where: { $0.getId() == shieldId }),
              activeShields.count < maxActiveShields else {
            return false
        }
        
        shield.deploy(at: position)
        activeShields.append(shield)
        return true
    }
    
    // MARK: - Shield Upgrades
    func canUpgrade(_ shieldId: String, stat: StatType) -> Bool {
        guard let shield = shields[shieldId],
              let requirement = shield.getUpgradeRequirement(stat, level: shield.getCurrentUpgradeLevel(stat) + 1) else {
            return false
        }
        
        return currencyManager.canAfford(requirement)
    }
    
    func upgradeShield(_ shieldId: String, stat: StatType) -> Bool {
        guard let shield = shields[shieldId],
              let requirement = shield.getUpgradeRequirement(stat, level: shield.getCurrentUpgradeLevel(stat) + 1) else {
            return false
        }
        
        if currencyManager.spend(requirement) {
            shield.upgrade(stat)
            NotificationCenter.default.post(
                name: .shieldUpgraded,
                object: nil,
                userInfo: [
                    "shieldId": shieldId,
                    "stat": stat.rawValue,
                    "level": shield.getCurrentUpgradeLevel(stat)
                ]
            )
            saveProgress()
            return true
        }
        
        NotificationCenter.default.post(name: .insufficientFunds, object: nil)
        return false
    }
    
    // MARK: - Update Loop
    func update(deltaTime: TimeInterval) {
        activeShields = activeShields.filter { shield in
            shield.update(deltaTime: deltaTime)
            return shield.isActive()
        }
    }
    
    // MARK: - Collision Handling
    func handleCollisions(with entities: [GKEntity]) {
        for shield in activeShields {
            for entity in entities {
                shield.handleCollision(with: entity)
            }
        }
    }
    
    // MARK: - Wave Management
    @objc private func handleWaveEnd() {
        activeShields.forEach { $0.destroy() }
        activeShields.removeAll()
    }
    
    // MARK: - Getters
    func getUnlockedShields() -> [Shield] {
        return unlockedShields.compactMap { shields[$0] }
    }
    
    func getEquippedShields() -> [Shield] {
        return equippedShields
    }
    
    func getActiveShields() -> [Shield] {
        return activeShields
    }
    
    func getShield(_ shieldId: String) -> Shield? {
        return shields[shieldId]
    }
    
    func getShieldsByRarity(_ rarity: Rarity) -> [Shield] {
        return shields.values.filter { $0.getRarity() == rarity }
    }
    
    // MARK: - Progress Management
    private func saveProgress() {
        let progress = ShieldProgress(
            unlockedShields: Array(unlockedShields),
            equippedShieldIds: equippedShields.map { $0.getId() },
            upgradeProgress: createUpgradeProgress()
        )
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(progress)
            UserDefaults.standard.set(data, forKey: "shieldProgress")
        } catch {
            print("Error saving shield progress: \(error)")
        }
    }
    
    private func loadProgress() {
        guard let data = UserDefaults.standard.data(forKey: "shieldProgress"),
              let progress = try? JSONDecoder().decode(ShieldProgress.self, from: data) else {
            return
        }
        
        unlockedShields = Set(progress.unlockedShields)
        equippedShields = []
        for shieldId in progress.equippedShieldIds {
            _ = equipShield(shieldId)
        }
        
        applyUpgradeProgress(progress.upgradeProgress)
    }
    
    private func createUpgradeProgress() -> [String: [String: Int]] {
        var progress: [String: [String: Int]] = [:]
        for (shieldId, shield) in shields {
            progress[shieldId] = Dictionary(
                uniqueKeysWithValues: shield.getAllUpgradeLevels().map {
                    (stat, level) in (stat, level)
                }
            )
        }
        return progress
    }
    
    private func applyUpgradeProgress(_ progress: [String: [String: Int]]) {
        for (shieldId, upgrades) in progress {
            guard let shield = shields[shieldId] else { continue }
            for (statString, level) in upgrades {
                if let stat = StatType(rawValue: statString) {
                    for _ in 0..<level {
                        _ = shield.upgrade(stat)
                    }
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    private func createShield(id: String, data: [String: Any]) -> Shield? {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: data)
            let decoder = JSONDecoder()
            let shieldInfo = try decoder.decode(ShieldInfo.self, from: jsonData)
            
            return Shield(
                id: id,
                name: shieldInfo.name,
                description: shieldInfo.description,
                type: shieldInfo.type,
                behavior: shieldInfo.behavior,
                rarity: shieldInfo.rarity,
                stats: shieldInfo.baseStats,
                visual: shieldInfo.visual,
                unlockRequirement: shieldInfo.unlockRequirement
            )
        } catch {
            print("Error creating shield: \(error)")
            return nil
        }
    }
}

// MARK: - Supporting Types
struct ShieldProgress: Codable {
    let unlockedShields: [String]
    let equippedShieldIds: [String]
    let upgradeProgress: [String: [String: Int]]
}

// MARK: - Notifications
extension Notification.Name {
    static let shieldUnlocked = Notification.Name("shieldUnlocked")
    static let shieldEquipped = Notification.Name("shieldEquipped")
    static let shieldUnequipped = Notification.Name("shieldUnequipped")
    static let shieldUpgraded = Notification.Name("shieldUpgraded")
    static let shieldDeployed = Notification.Name("shieldDeployed")
    static let shieldDestroyed = Notification.Name("shieldDestroyed")
    static let waveCompleted = Notification.Name("waveCompleted")
}

// MARK: - Debug Helpers
#if DEBUG
extension ShieldManager {
    func resetProgress() {
        unlockedShields = Set(["basicBarrier"])
        equippedShields = []
        if let basicBarrier = shields["basicBarrier"] {
            equippedShields = [basicBarrier]
        }
        activeShields.removeAll()
        saveProgress()
    }
    
    func unlockAll() {
        unlockedShields = Set(shields.keys)
        saveProgress()
    }
    
    func debugDeployAllShields(at position: Vector2) {
        for shield in equippedShields {
            _ = deployShield(shield.getId(), at: position)
        }
    }
}
#endif
