import Foundation

class DurationManager {
    // MARK: - Properties
    static let shared = DurationManager()
    
    private var activeEffects: [String: ActiveEffect] = [:]
    private var cooldowns: [String: Cooldown] = [:]
    private var waveBasedEffects: [String: WaveEffect] = [:]
    private var currentWave: Int = 0
    private var gameTime: TimeInterval = 0
    private var isGamePaused: Bool = false
    
    // MARK: - Types
    struct ActiveEffect {
        let id: String
        let type: DurationType
        let startTime: TimeInterval
        let duration: TimeInterval
        var remainingDuration: TimeInterval
        let callback: (() -> Void)?
        
        var isExpired: Bool {
            switch type {
            case .timed:
                return remainingDuration <= 0
            case .permanent:
                return false
            case .wave:
                return false  // Handled separately
            }
        }
    }
    
    struct Cooldown {
        let id: String
        let duration: TimeInterval
        var remainingTime: TimeInterval
        let callback: (() -> Void)?
    }
    
    struct WaveEffect {
        let id: String
        let startWave: Int
        let duration: Int  // Number of waves
        let callback: (() -> Void)?
    }
    
    enum DurationType {
        case timed(TimeInterval)
        case permanent
        case wave(Int)  // Number of waves
    }
    
    // MARK: - Effect Management
    func addEffect(
        id: String,
        type: DurationType,
        callback: (() -> Void)? = nil
    ) {
        switch type {
        case .timed(let duration):
            let effect = ActiveEffect(
                id: id,
                type: type,
                startTime: gameTime,
                duration: duration,
                remainingDuration: duration,
                callback: callback
            )
            activeEffects[id] = effect
            
        case .permanent:
            let effect = ActiveEffect(
                id: id,
                type: type,
                startTime: gameTime,
                duration: TimeInterval.infinity,
                remainingDuration: TimeInterval.infinity,
                callback: callback
            )
            activeEffects[id] = effect
            
        case .wave(let waves):
            let effect = WaveEffect(
                id: id,
                startWave: currentWave,
                duration: waves,
                callback: callback
            )
            waveBasedEffects[id] = effect
        }
        
        NotificationCenter.default.post(
            name: .effectAdded,
            object: nil,
            userInfo: ["effectId": id]
        )
    }
    
    func removeEffect(id: String) {
        activeEffects.removeValue(forKey: id)
        waveBasedEffects.removeValue(forKey: id)
        
        NotificationCenter.default.post(
            name: .effectRemoved,
            object: nil,
            userInfo: ["effectId": id]
        )
    }
    
    // MARK: - Cooldown Management
    func startCooldown(
        id: String,
        duration: TimeInterval,
        callback: (() -> Void)? = nil
    ) {
        let cooldown = Cooldown(
            id: id,
            duration: duration,
            remainingTime: duration,
            callback: callback
        )
        cooldowns[id] = cooldown
        
        NotificationCenter.default.post(
            name: .cooldownStarted,
            object: nil,
            userInfo: [
                "cooldownId": id,
                "duration": duration
            ]
        )
    }
    
    func isOnCooldown(_ id: String) -> Bool {
        return cooldowns[id]?.remainingTime ?? 0 > 0
    }
    
    func getRemainingCooldown(_ id: String) -> TimeInterval {
        return cooldowns[id]?.remainingTime ?? 0
    }
    
    // MARK: - Wave Management
    func startNewWave() {
        currentWave += 1
        checkWaveBasedEffects()
        
        NotificationCenter.default.post(
            name: .waveStarted,
            object: nil,
            userInfo: ["waveNumber": currentWave]
        )
    }
    
    private func checkWaveBasedEffects() {
        waveBasedEffects = waveBasedEffects.filter { id, effect in
            let wavesElapsed = currentWave - effect.startWave
            if wavesElapsed >= effect.duration {
                effect.callback?()
                
                NotificationCenter.default.post(
                    name: .effectExpired,
                    object: nil,
                    userInfo: ["effectId": id]
                )
                return false
            }
            return true
        }
    }
    
    // MARK: - Time Management
    func update(deltaTime: TimeInterval) {
        guard !isGamePaused else { return }
        
        gameTime += deltaTime
        
        // Update active effects
        activeEffects = activeEffects.filter { id, effect in
            if case .timed = effect.type {
                var updatedEffect = effect
                updatedEffect.remainingDuration -= deltaTime
                
                if updatedEffect.isExpired {
                    effect.callback?()
                    NotificationCenter.default.post(
                        name: .effectExpired,
                        object: nil,
                        userInfo: ["effectId": id]
                    )
                    return false
                }
                
                activeEffects[id] = updatedEffect
            }
            return true
        }
        
        // Update cooldowns
        cooldowns = cooldowns.filter { id, cooldown in
            var updatedCooldown = cooldown
            updatedCooldown.remainingTime -= deltaTime
            
            if updatedCooldown.remainingTime <= 0 {
                cooldown.callback?()
                NotificationCenter.default.post(
                    name: .cooldownComplete,
                    object: nil,
                    userInfo: ["cooldownId": id]
                )
                return false
            }
            
            cooldowns[id] = updatedCooldown
            return true
        }
    }
    
    func pauseGame() {
        isGamePaused = true
    }
    
    func resumeGame() {
        isGamePaused = false
    }
    
    // MARK: - Queries
    func isEffectActive(_ id: String) -> Bool {
        if let effect = activeEffects[id] {
            return !effect.isExpired
        }
        return waveBasedEffects[id] != nil
    }
    
    func getRemainingDuration(_ id: String) -> TimeInterval? {
        return activeEffects[id]?.remainingDuration
    }
    
    func getRemainingWaves(_ id: String) -> Int? {
        guard let effect = waveBasedEffects[id] else { return nil }
        return effect.duration - (currentWave - effect.startWave)
    }
    
    // MARK: - Reset
    func reset() {
        activeEffects.removeAll()
        cooldowns.removeAll()
        waveBasedEffects.removeAll()
        currentWave = 0
        gameTime = 0
        isGamePaused = false
    }
}

// MARK: - Notifications
extension Notification.Name {
    static let effectAdded = Notification.Name("effectAdded")
    static let effectRemoved = Notification.Name("effectRemoved")
    static let effectExpired = Notification.Name("effectExpired")
    static let cooldownStarted = Notification.Name("cooldownStarted")
    static let cooldownComplete = Notification.Name("cooldownComplete")
    static let waveStarted = Notification.Name("waveStarted")
}

// MARK: - Debug Helpers
#if DEBUG
extension DurationManager {
    func debugPrintActiveEffects() {
        print("Active Effects:")
        activeEffects.forEach { id, effect in
            print("- \(id): \(effect.remainingDuration)s remaining")
        }
        
        print("\nWave-based Effects:")
        waveBasedEffects.forEach { id, effect in
            let remaining = effect.duration - (currentWave - effect.startWave)
            print("- \(id): \(remaining) waves remaining")
        }
        
        print("\nActive Cooldowns:")
        cooldowns.forEach { id, cooldown in
            print("- \(id): \(cooldown.remainingTime)s remaining")
        }
    }
    
    func debugSkipTime(_ seconds: TimeInterval) {
        update(deltaTime: seconds)
    }
    
    func debugSkipWaves(_ count: Int) {
        for _ in 0..<count {
            startNewWave()
        }
    }
}
#endif
