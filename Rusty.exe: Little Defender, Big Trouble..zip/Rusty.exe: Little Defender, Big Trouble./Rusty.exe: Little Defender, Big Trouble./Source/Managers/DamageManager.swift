import Foundation
import CoreGraphics

class DamageManager {
    // MARK: - Properties
    static let shared = DamageManager()

    private let statManager = StatManager.shared
    private let durationManager = DurationManager.shared

    // MARK: - Types
    struct DamageInfo {
        let amount: CGFloat
        let type: DamageType
        let source: DamageSource
        let isCritical: Bool
        let penetration: CGFloat
        var modifiers: [DamageModifier]

        init(
            amount: CGFloat,
            type: DamageType,
            source: DamageSource,
            isCritical: Bool = false,
            penetration: CGFloat = 0,
            modifiers: [DamageModifier] = []
        ) {
            self.amount = amount
            self.type = type
            self.source = source
            self.isCritical = isCritical
            self.penetration = penetration
            self.modifiers = modifiers
        }
    }

    enum DamageType: String, Codable {
        case physical
        case energy
        case explosive
        case quantum
        case lightning
        case gravity
        case temporal
        case plasma

        var color: String {
            switch self {
            case .physical: return "#ffffff"
            case .energy: return "#00ffff"
            case .explosive: return "#ff8800"
            case .quantum: return "#ff00ff"
            case .lightning: return "#ffff00"
            case .gravity: return "#7700ff"
            case .temporal: return "#00ff88"
            case .plasma: return "#ff0000"
            }
        }
    }

    enum DamageSource {
        case weapon(String)
        case shield(String)
        case patch(String)
        case environment
        case dot(String)
    }

    struct DamageModifier {
        let type: ModifierType
        let value: CGFloat

        enum ModifierType {
            case multiply
            case add
            case reduce
            case amplify
        }
    }

    struct DamageResult {
        let originalDamage: CGFloat
        let finalDamage: CGFloat
        let isCritical: Bool
        let wasBlocked: Bool
        let penetratedArmor: Bool
        let killedTarget: Bool
    }

    // MARK: - Damage Calculation
    func calculateDamage(_ info: DamageInfo, target: Entity) -> DamageResult {
        var damage = info.amount
        let originalDamage = damage

        // Apply critical multiplier
        if info.isCritical {
            damage *= statManager.getStat(.criticalMultiplier)
        }

        // Apply damage modifiers
        for modifier in info.modifiers {
            switch modifier.type {
            case .multiply:
                damage *= modifier.value
            case .add:
                damage += modifier.value
            case .reduce:
                damage -= modifier.value
            case .amplify:
                damage *= (1 + modifier.value)
            }
        }

        // Armor calculation
        let penetratedArmor = applyPenetration(info.penetration, target: target)
        let wasBlocked = !penetratedArmor
        if wasBlocked {
            damage = applyArmor(damage, target: target)
        }

        // Resistance calculation
        damage = applyResistance(damage, type: info.type, target: target)

        // Apply damage to health
        let killed = applyHealthDamage(damage, target: target)

        return DamageResult(
            originalDamage: originalDamage,
            finalDamage: damage,
            isCritical: info.isCritical,
            wasBlocked: wasBlocked,
            penetratedArmor: penetratedArmor,
            killedTarget: killed
        )
    }

    private func applyPenetration(_ value: CGFloat, target: Entity) -> Bool {
        guard let armor = target.getComponent(ofType: ArmorComponent.self) else { return true }
        return value >= armor.armorValue
    }

    private func applyArmor(_ damage: CGFloat, target: Entity) -> CGFloat {
        guard let armor = target.getComponent(ofType: ArmorComponent.self) else { return damage }
        let reduced = max(0, damage - armor.armorValue)
        return reduced
    }

    private func applyResistance(_ damage: CGFloat, type: DamageType, target: Entity) -> CGFloat {
        guard let resist = target.getComponent(ofType: ResistanceComponent.self) else { return damage }
        let resistanceValue = resist.resistances[type] ?? 0
        return damage * (1.0 - resistanceValue)
    }

    private func applyHealthDamage(_ damage: CGFloat, target: Entity) -> Bool {
        guard var health = target.getComponent(ofType: HealthComponent.self) else { return false }
        health.currentHealth -= damage
        if health.currentHealth <= 0 {
            // TODO: Implement death logic here (e.g., set isDead = true or notify system)
            return true
        }
        return false
    }
}
