import Foundation

class PlayerManager {
    static let shared = PlayerManager()

    // MARK: - Keys for persistence
    private let equippedWeaponsKey = "equippedWeapons"
    private let weaponUpgradeLevelsKey = "weaponUpgradeLevels"
    private let gemBalanceKey = "playerGems"
    private let pointsKey = "playerPoints"
    private let dualWieldUnlockedKey = "dualWieldUnlocked"
    private let unlockedWeaponsKey = "unlockedWeapons"

    // MARK: - Properties
    private(set) var equippedLeftWeaponID: String?
    private(set) var equippedRightWeaponID: String?
    private(set) var weaponUpgradeLevels: [String: [StatType: Int]] = [:]
    private(set) var gems: Int = 0
    private(set) var points: Int = 0
    private(set) var dualWieldUnlocked: Bool = false
    private var unlockedWeapons: Set<String> = []

    // MARK: - Initialization
    private init() {
        loadFromDisk()
    }

    // MARK: - Weapon Management
    func equipWeapon(id: String, isLeft: Bool) {
        if isLeft {
            equippedLeftWeaponID = id
        } else {
            equippedRightWeaponID = id
        }
        saveToDisk()
    }

    func getEquippedWeaponID(isLeft: Bool) -> String? {
        return isLeft ? equippedLeftWeaponID : equippedRightWeaponID
    }

    func unlockDualWield() {
        dualWieldUnlocked = true
        saveToDisk()
    }

    func isDualWieldUnlocked() -> Bool {
        return dualWieldUnlocked
    }

    func isWeaponUnlocked(_ weaponId: String) -> Bool {
        return unlockedWeapons.contains(weaponId)
    }

    func unlockWeapon(_ weaponId: String) {
        unlockedWeapons.insert(weaponId)
        saveToDisk()
    }

    // MARK: - Upgrade Tracking
    func setUpgradeLevel(for weaponID: String, stat: StatType, level: Int) {
        if weaponUpgradeLevels[weaponID] == nil {
            weaponUpgradeLevels[weaponID] = [:]
        }
        weaponUpgradeLevels[weaponID]?[stat] = level
        saveToDisk()
    }

    func getUpgradeLevel(for weaponID: String, stat: StatType) -> Int {
        return weaponUpgradeLevels[weaponID]?[stat] ?? 0
    }

    func upgradeWeaponStat(weaponID: String, stat: StatType, upgradePath: [UpgradeLevel]) -> Bool {
        let currentLevel = getUpgradeLevel(for: weaponID, stat: stat)
        guard currentLevel < upgradePath.count else { return false }

        let nextUpgrade = upgradePath[currentLevel]
        let cost = nextUpgrade.requirement.gems ?? 0

        guard spendGems(cost) else { return false }

        setUpgradeLevel(for: weaponID, stat: stat, level: currentLevel + 1)
        return true
    }

    // MARK: - Currency Helpers
    func canAfford(_ requirement: CurrencyRequirement) -> Bool {
        let gemsOK = requirement.gems == nil || gems >= requirement.gems!
        let pointsOK = requirement.points == nil || points >= requirement.points!
        return gemsOK && pointsOK
    }

    func deduct(_ requirement: CurrencyRequirement) -> Bool {
        guard canAfford(requirement) else { return false }

        if let gemsCost = requirement.gems {
            gems -= gemsCost
        }

        if let pointsCost = requirement.points {
            points -= pointsCost
        }

        saveToDisk()
        return true
    }

    // MARK: - Currency Management
    func addGems(_ amount: Int) {
        gems += amount
        saveToDisk()
    }

    func spendGems(_ amount: Int) -> Bool {
        guard gems >= amount else { return false }
        gems -= amount
        saveToDisk()
        return true
    }

    func getGemBalance() -> Int {
        return gems
    }

    func addPoints(_ amount: Int) {
        points += amount
        saveToDisk()
    }

    func getPoints() -> Int {
        return points
    }

    // MARK: - Persistence
    private func saveToDisk() {
        let defaults = UserDefaults.standard
        defaults.set(equippedLeftWeaponID, forKey: "\(equippedWeaponsKey)_left")
        defaults.set(equippedRightWeaponID, forKey: "\(equippedWeaponsKey)_right")
        defaults.set(gems, forKey: gemBalanceKey)
        defaults.set(points, forKey: pointsKey)
        defaults.set(dualWieldUnlocked, forKey: dualWieldUnlockedKey)
        defaults.set(Array(unlockedWeapons), forKey: unlockedWeaponsKey)

        if let encodedUpgrades = try? JSONEncoder().encode(weaponUpgradeLevels) {
            defaults.set(encodedUpgrades, forKey: weaponUpgradeLevelsKey)
        }
    }

    private func loadFromDisk() {
        let defaults = UserDefaults.standard
        equippedLeftWeaponID = defaults.string(forKey: "\(equippedWeaponsKey)_left")
        equippedRightWeaponID = defaults.string(forKey: "\(equippedWeaponsKey)_right")
        gems = defaults.integer(forKey: gemBalanceKey)
        points = defaults.integer(forKey: pointsKey)
        dualWieldUnlocked = defaults.bool(forKey: dualWieldUnlockedKey)

        if let array = defaults.stringArray(forKey: unlockedWeaponsKey) {
            unlockedWeapons = Set(array)
        }

        if let data = defaults.data(forKey: weaponUpgradeLevelsKey),
           let decoded = try? JSONDecoder().decode([String: [StatType: Int]].self, from: data) {
            weaponUpgradeLevels = decoded
        }
    }
}
