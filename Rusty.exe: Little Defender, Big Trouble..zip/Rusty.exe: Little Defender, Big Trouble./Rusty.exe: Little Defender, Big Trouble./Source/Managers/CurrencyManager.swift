import Foundation

class CurrencyManager {
    static let shared = CurrencyManager()
    
    private(set) var currentCurrency: Currency = .zero {
        didSet {
            save()
            NotificationCenter.default.post(name: .currencyDidChange, object: nil)
        }
    }
    
    private let saveKey = "playerCurrency"
    
    private init() {
        load()
    }
    
    // MARK: - Currency Management
    func add(currency: Currency) {
        currentCurrency.points += currency.points
        currentCurrency.gems += currency.gems
    }
    
    func canAfford(_ requirement: CurrencyRequirement) -> Bool {
        return currentCurrency.canAfford(requirement)
    }
    
    func spend(_ requirement: CurrencyRequirement) -> Bool {
        guard canAfford(requirement) else { return false }
        
        if let points = requirement.points {
            currentCurrency.points -= points
        }
        if let gems = requirement.gems {
            currentCurrency.gems -= gems
        }
        return true
    }
    
    // MARK: - Gameplay Rewards
    func awardGameplayGems(chance: Double = 0.05) {
        // 5% chance to award a gem
        if Double.random(in: 0...1) < chance {
            add(currency: Currency(points: 0, gems: 1))
            NotificationCenter.default.post(name: .gemsAwarded, object: nil)
        }
    }
    
    func awardLevelComplete(level: Int) {
        // Base reward plus bonus for higher levels
        let basePoints = 100
        let levelBonus = level * 50
        add(currency: Currency(points: basePoints + levelBonus, gems: 0))
    }
    
    // MARK: - IAP
    func processPurchase(package: GemPackage) {
        add(currency: Currency(points: 0, gems: package.totalGems))
        recordTransaction(.gemsPurchased, amount: package.totalGems)
    }
    
    // MARK: - Transaction Recording
    private func recordTransaction(_ type: CurrencyTransaction.TransactionType, amount: Int) {
        let transaction = CurrencyTransaction(
            id: UUID(),
            type: type,
            amount: amount,
            timestamp: Date(),
            source: .purchase,
            itemId: nil
        )
        // Store transaction history if needed
    }
    
    // MARK: - Persistence
    private func save() {
        if let encoded = try? JSONEncoder().encode(currentCurrency) {
            UserDefaults.standard.set(encoded, forKey: saveKey)
        }
    }
    
    private func load() {
        if let data = UserDefaults.standard.data(forKey: saveKey),
           let currency = try? JSONDecoder().decode(Currency.self, from: data) {
            currentCurrency = currency
        }
    }
}

// MARK: - Notifications
extension Notification.Name {
    static let currencyDidChange = Notification.Name("currencyDidChange")
    static let gemsAwarded = Notification.Name("gemsAwarded")
    static let insufficientFunds = Notification.Name("insufficientFunds")
}

#if DEBUG
extension CurrencyManager {
    func resetCurrency() {
        currentCurrency = .zero
    }
    
    func addDebugCurrency(points: Int, gems: Int) {
        add(currency: Currency(points: points, gems: gems))
    }
}
#endif
