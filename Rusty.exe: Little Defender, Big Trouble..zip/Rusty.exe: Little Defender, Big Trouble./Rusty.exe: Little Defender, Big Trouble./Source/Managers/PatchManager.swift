import GameplayKit

class PatchManager {
    // MARK: - Properties
    static let shared = PatchManager()
    
    private var availablePatches: [String: SoftwarePatch] = [:]
    private var unlockedPatches: Set<String> = []
    private var equippedPatches: [SoftwarePatch] = []
    private let maxEquippedPatches = 3
    private var patchesData: [String: Any]?
    private let currencyManager = CurrencyManager.shared
    
    weak var player: Player?
    
    // MARK: - Initialization
    private init() {
        loadPatchesData()
        loadProgress()
    }
    
    private func loadPatchesData() {
        guard let url = Bundle.main.url(forResource: "patches", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
            print("Failed to load patches data")
            return
        }
        
        patchesData = json["patches"] as? [String: Any]
        initializePatches()
    }
    
    private func initializePatches() {
        patchesData?.forEach { patchId, patchData in
            if let patchDict = patchData as? [String: Any] {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: patchDict)
                    let decoder = JSONDecoder()
                    let patchInfo = try decoder.decode(PatchInfo.self, from: jsonData)
                    
                    let patch = SoftwarePatch(
                        id: patchId,
                        name: patchInfo.name,
                        description: patchInfo.description,
                        type: patchInfo.type,
                        rarity: patchInfo.rarity,
                        effects: patchInfo.effects,
                        visual: patchInfo.visual
                    )
                    
                    patch.delegate = self
                    availablePatches[patchId] = patch
                } catch {
                    print("Error creating patch: \(error)")
                }
            }
        }
    }
    
    // MARK: - Patch Management
    func canUnlock(_ patchId: String) -> Bool {
        guard let patch = availablePatches[patchId],
              !unlockedPatches.contains(patchId) else {
            return false
        }
        
        return currencyManager.canAfford(patch.unlockRequirement)
    }
    
    func unlockPatch(_ patchId: String) -> Bool {
        guard let patch = availablePatches[patchId],
              !unlockedPatches.contains(patchId) else {
            return false
        }
        
        if currencyManager.spend(patch.unlockRequirement) {
            unlockedPatches.insert(patchId)
            NotificationCenter.default.post(
                name: .patchUnlocked,
                object: nil,
                userInfo: ["patchId": patchId]
            )
            savePatchProgress()
            return true
        }
        
        NotificationCenter.default.post(name: .insufficientFunds, object: nil)
        return false
    }
    
    func equipPatch(_ patchId: String) -> Bool {
        guard unlockedPatches.contains(patchId),
              let patch = availablePatches[patchId],
              equippedPatches.count < maxEquippedPatches else {
            return false
        }
        
        equippedPatches.append(patch)
        
        // Initialize passive patches immediately
        if patch.getType() == .passive {
            patch.tryActivate(trigger: .healthThreshold(percentage: 1.0))
        }
        
        NotificationCenter.default.post(
            name: .patchEquipped,
            object: nil,
            userInfo: ["patchId": patchId]
        )
        savePatchProgress()
        return true
    }
    
    func unequipPatch(_ patchId: String) -> Bool {
        guard let index = equippedPatches.firstIndex(where: { $0.getId() == patchId }) else {
            return false
        }
        
        let patch = equippedPatches.remove(at: index)
        patch.deactivate()
        
        NotificationCenter.default.post(
            name: .patchUnequipped,
            object: nil,
            userInfo: ["patchId": patchId]
        )
        savePatchProgress()
        return true
    }
    
    // MARK: - Trigger Handling
    func handlePlayerDeath() {
        let deathTrigger = TriggerCondition.death
        activateTriggeredPatches(deathTrigger)
    }
    
    func handleHealthChange(newPercentage: CGFloat) {
        let healthTrigger = TriggerCondition.healthThreshold(percentage: newPercentage)
        activateTriggeredPatches(healthTrigger)
    }
    
    private func activateTriggeredPatches(_ trigger: TriggerCondition) {
        for patch in equippedPatches {
            patch.tryActivate(trigger: trigger)
        }
    }
    
    // MARK: - Wave Management
    func onWaveEnd() {
        for patch in equippedPatches {
            patch.deactivate()
        }
    }
    
    // MARK: - SoftwarePatchDelegate
    func patch(_ patch: SoftwarePatch, didActivateWithEffects effects: PatchEffects) {
        guard let player = player else { return }
        
        if let component = patch.component(ofType: PatchEffectComponent.self) {
            component.applyEffects(to: player)
        }
    }
    
    func patchDidDeactivate(_ patch: SoftwarePatch) {
        guard let player = player else { return }
        
        if let component = patch.component(ofType: PatchEffectComponent.self) {
            component.removeEffects(from: player)
        }
        
        if let component = patch.component(ofType: PatchVisualComponent.self) {
            component.removeVisualEffects()
        }
    }
    
    func patch(_ patch: SoftwarePatch, didConvertDamageToEnergy energy: CGFloat) {
        player?.addShieldEnergy(energy)
    }
    
    // MARK: - Getters
    func getUnlockedPatches() -> [SoftwarePatch] {
        return unlockedPatches.compactMap { availablePatches[$0] }
    }
    
    func getEquippedPatches() -> [SoftwarePatch] {
        return equippedPatches
    }
    
    func getPatchesByRarity(_ rarity: String) -> [SoftwarePatch] {
        return availablePatches.values.filter { $0.getRarity() == rarity }
    }
    
    // MARK: - Progress Persistence
    private func savePatchProgress() {
        let progress = PatchProgress(
            unlockedPatches: Array(unlockedPatches),
            equippedPatchIds: equippedPatches.map { $0.getId() }
        )
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(progress)
            UserDefaults.standard.set(data, forKey: "patchProgress")
        } catch {
            print("Error saving patch progress: \(error)")
        }
    }
    
    private func loadProgress() {
        guard let data = UserDefaults.standard.data(forKey: "patchProgress"),
              let progress = try? JSONDecoder().decode(PatchProgress.self, from: data) else {
            return
        }
        
        unlockedPatches = Set(progress.unlockedPatches)
        progress.equippedPatchIds.forEach { patchId in
            equipPatch(patchId)
        }
    }
}

// MARK: - Supporting Types
struct PatchInfo: Codable {
    let name: String
    let description: String
    let type: PatchType
    let rarity: String
    let effects: PatchEffects
    let visual: PatchVisual
    let unlockRequirement: CurrencyRequirement
}

struct PatchProgress: Codable {
    let unlockedPatches: [String]
    let equippedPatchIds: [String]
}

// MARK: - Notifications
extension Notification.Name {
    static let patchUnlocked = Notification.Name("patchUnlocked")
    static let patchEquipped = Notification.Name("patchEquipped")
    static let patchUnequipped = Notification.Name("patchUnequipped")
    static let patchActivated = Notification.Name("patchActivated")
    static let patchDeactivated = Notification.Name("patchDeactivated")
}

// MARK: - Debug Helpers
#if DEBUG
extension PatchManager {
    func resetProgress() {
        unlockedPatches.removeAll()
        equippedPatches.removeAll()
        savePatchProgress()
    }
    
    func unlockAll() {
        unlockedPatches = Set(availablePatches.keys)
        savePatchProgress()
    }
    
    func debugActivateAllPatches() {
        for patch in equippedPatches {
            patch.tryActivate(trigger: .healthThreshold(percentage: 1.0))
        }
    }
}
#endif
