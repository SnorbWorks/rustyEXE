import Foundation

class StatManager {
    // MARK: - Properties
    static let shared = StatManager()
    
    private var baseStats: [StatType: CGFloat] = [:]
    private var temporaryModifiers: [StatType: [(value: CGFloat, expiryTime: TimeInterval)]] = [:]
    private var permanentModifiers: [StatType: [CGFloat]] = [:]
    private var percentageModifiers: [StatType: [CGFloat]] = [:]
    
    // MARK: - Initialization
    private init() {
        initializeBaseStats()
    }
    
    private func initializeBaseStats() {
        // Initialize all stats with their default values
        for stat in StatType.allCases {
            baseStats[stat] = stat.defaultValue
        }
    }
    
    // MARK: - Stat Management
    func getStat(_ stat: StatType) -> CGFloat {
        let base = baseStats[stat] ?? stat.defaultValue
        let flatModifiers = calculateFlatModifiers(for: stat)
        let percentModifiers = calculatePercentageModifiers(for: stat)
        
        // Apply flat modifiers first, then percentage modifiers
        let withFlat = base + flatModifiers
        let final = withFlat * (1 + percentModifiers)
        
        // Clamp to max value if one exists
        return min(final, stat.maxValue)
    }
    
    func getBaseValue(_ stat: StatType) -> CGFloat {
        return baseStats[stat] ?? stat.defaultValue
    }
    
    func setBaseStat(_ stat: StatType, value: CGFloat) {
        baseStats[stat] = value
    }
    
    // MARK: - Modifier Management
    func addTemporaryModifier(_ stat: StatType, value: CGFloat, duration: TimeInterval) {
        let expiryTime = CACurrentMediaTime() + duration
        temporaryModifiers[stat, default: []].append((value, expiryTime))
        
        // Schedule cleanup
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
            self?.cleanupExpiredModifiers()
        }
        
        NotificationCenter.default.post(
            name: .statModifierAdded,
            object: nil,
            userInfo: [
                "stat": stat,
                "value": value,
                "duration": duration
            ]
        )
    }
    
    func addPermanentModifier(_ stat: StatType, value: CGFloat) {
        permanentModifiers[stat, default: []].append(value)
        
        NotificationCenter.default.post(
            name: .statModifierAdded,
            object: nil,
            userInfo: [
                "stat": stat,
                "value": value,
                "isPermanent": true
            ]
        )
    }
    
    func addPercentageModifier(_ stat: StatType, percentage: CGFloat) {
        percentageModifiers[stat, default: []].append(percentage)
        
        NotificationCenter.default.post(
            name: .statModifierAdded,
            object: nil,
            userInfo: [
                "stat": stat,
                "percentage": percentage
            ]
        )
    }
    
    func removeAllModifiers(for stat: StatType) {
        temporaryModifiers[stat]?.removeAll()
        permanentModifiers[stat]?.removeAll()
        percentageModifiers[stat]?.removeAll()
        
        NotificationCenter.default.post(
            name: .statModifiersCleared,
            object: nil,
            userInfo: ["stat": stat]
        )
    }
    
    // MARK: - Calculations
    private func calculateFlatModifiers(for stat: StatType) -> CGFloat {
        let currentTime = CACurrentMediaTime()
        
        // Sum temporary modifiers that haven't expired
        let temporarySum = temporaryModifiers[stat]?
            .filter { $0.expiryTime > currentTime }
            .reduce(0) { $0 + $1.value } ?? 0
        
        // Sum permanent modifiers
        let permanentSum = permanentModifiers[stat]?
            .reduce(0, +) ?? 0
        
        return temporarySum + permanentSum
    }
    
    private func calculatePercentageModifiers(for stat: StatType) -> CGFloat {
        return percentageModifiers[stat]?
            .reduce(0, +) ?? 0
    }
    
    // MARK: - Cleanup
    private func cleanupExpiredModifiers() {
        let currentTime = CACurrentMediaTime()
        
        for (stat, modifiers) in temporaryModifiers {
            temporaryModifiers[stat] = modifiers.filter { $0.expiryTime > currentTime }
        }
    }
    
    // MARK: - Stat Formatting
    func getFormattedStat(_ stat: StatType) -> String {
        let value = getStat(stat)
        let format = stat.format
        
        if stat.isPercentage {
            return String(format: format, value * 100)
        }
        return String(format: format, value)
    }
    
    // MARK: - Category Management
    func getStatsInCategory(_ category: StatCategory) -> [StatType] {
        return StatType.allCases.filter { $0.category == category }
    }
    
    // MARK: - Save/Load
    func save() {
        let statsData = StatsData(
            baseStats: baseStats,
            permanentModifiers: permanentModifiers,
            percentageModifiers: percentageModifiers
        )
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(statsData)
            UserDefaults.standard.set(data, forKey: "statsData")
        } catch {
            print("Error saving stats: \(error)")
        }
    }
    
    func load() {
        guard let data = UserDefaults.standard.data(forKey: "statsData"),
              let statsData = try? JSONDecoder().decode(StatsData.self, from: data) else {
            return
        }
        
        baseStats = statsData.baseStats
        permanentModifiers = statsData.permanentModifiers
        percentageModifiers = statsData.percentageModifiers
    }
}

// MARK: - Supporting Types
struct StatsData: Codable {
    let baseStats: [StatType: CGFloat]
    let permanentModifiers: [StatType: [CGFloat]]
    let percentageModifiers: [StatType: [CGFloat]]
}

// MARK: - Notifications
extension Notification.Name {
    static let statModifierAdded = Notification.Name("statModifierAdded")
    static let statModifiersCleared = Notification.Name("statModifiersCleared")
    static let statBaseValueChanged = Notification.Name("statBaseValueChanged")
}

// MARK: - Debug Helpers
#if DEBUG
extension StatManager {
    func resetAllStats() {
        initializeBaseStats()
        temporaryModifiers.removeAll()
        permanentModifiers.removeAll()
        percentageModifiers.removeAll()
    }
    
    func printStatBreakdown(for stat: StatType) {
        print("Stat Breakdown for \(stat.displayName):")
        print("Base Value: \(getBaseValue(stat))")
        print("Temporary Modifiers: \(temporaryModifiers[stat] ?? [])")
        print("Permanent Modifiers: \(permanentModifiers[stat] ?? [])")
        print("Percentage Modifiers: \(percentageModifiers[stat] ?? [])")
        print("Final Value: \(getStat(stat))")
    }
}
#endif
