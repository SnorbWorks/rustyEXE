class PowerupManager {
    static let shared = PowerupManager()
    
    private var activePowerups: [Powerup] = []
    
    func awardPowerup(_ type: PowerupType) {
        let powerup = createPowerup(type)
        activePowerups.append(powerup)
        applyPowerupEffects(powerup)
        
        // Schedule powerup expiration
        DispatchQueue.main.asyncAfter(deadline: .now() + powerup.duration) { [weak self] in
            self?.removePowerup(powerup)
        }
    }
    
    private func removePowerup(_ powerup: Powerup) {
        activePowerups.removeAll { $0.id == powerup.id }
        removePowerupEffects(powerup)
    }
}

struct Powerup {
    let id: UUID
    let type: PowerupType
    let duration: TimeInterval
    let effects: [PowerupEffect]
}

enum PowerupType {
    case damageBoost(multiplier: Float)
    case fireRateBoost(multiplier: Float)
    case shieldRegeneration(amount: Float)
    case multiShot(count: Int)
    // Add more powerup types
}
