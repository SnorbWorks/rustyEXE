import GameplayKit

class SkinManager {
    // MARK: - Properties
    static let shared = SkinManager()
    
    private var skins: [String: Skin] = [:]
    private var currentSkin: Skin?
    private var unlockedSkins: Set<String> = []
    private var skinsData: [String: Any]?
    
    // MARK: - Initialization
    private init() {
        loadSkinsData()
        initializeDefaultSkin()
    }
    
    // MARK: - Data Loading
    private func loadSkinsData() {
        guard let url = Bundle.main.url(forResource: "skins", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
            print("Failed to load skins data")
            return
        }
        
        skinsData = json["skins"] as? [String: Any]
        initializeAllSkins()
    }
    
    private func initializeAllSkins() {
        skinsData?.forEach { skinId, skinData in
            if let skinDict = skinData as? [String: Any] {
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: skinDict)
                    let decoder = JSONDecoder()
                    let skinInfo = try decoder.decode(SkinInfo.self, from: jsonData)
                    
                    let skin = Skin(
                        id: skinId,
                        name: skinInfo.name,
                        description: skinInfo.description,
                        rarity: skinInfo.rarity,
                        unlockCondition: skinInfo.unlockCondition,
                        visual: skinInfo.visual
                    )
                    
                    skins[skinId] = skin
                    
                    // Unlock default skin
                    if case .defaultSkin = skinInfo.unlockCondition.requirement {
                        unlockedSkins.insert(skinId)
                    }
                } catch {
                    print("Error creating skin: \(error)")
                }
            }
        }
    }
    
    private func initializeDefaultSkin() {
        if let defaultSkin = skins.first(where: { $0.value.getRarity() == "common" }) {
            currentSkin = defaultSkin.value
            unlockedSkins.insert(defaultSkin.key)
        }
    }
    
    // MARK: - Skin Management
    func checkAndUnlockSkins(playerStats: PlayerStats) {
        skins.forEach { skinId, skin in
            if !unlockedSkins.contains(skinId) && skin.checkUnlockCondition(playerStats: playerStats) {
                unlockSkin(skinId)
                NotificationCenter.default.post(
                    name: .skinUnlocked,
                    object: nil,
                    userInfo: ["skinId": skinId]
                )
            }
        }
    }
    
    func unlockSkin(_ skinId: String) {
        if let skin = skins[skinId] {
            skin.unlock()
            unlockedSkins.insert(skinId)
            saveSkinProgress()
        }
    }
    
    func equipSkin(_ skinId: String) -> Bool {
        guard unlockedSkins.contains(skinId),
              let skin = skins[skinId] else {
            return false
        }
        
        currentSkin = skin
        saveSkinProgress()
        NotificationCenter.default.post(
            name: .skinEquipped,
            object: nil,
            userInfo: ["skinId": skinId]
        )
        return true
    }
    
    // MARK: - Getters
    func getCurrentSkin() -> Skin? {
        return currentSkin
    }
    
    func getAllSkins() -> [Skin] {
        return Array(skins.values)
    }
    
    func getUnlockedSkins() -> [Skin] {
        return skins.filter { unlockedSkins.contains($0.key) }.map { $0.value }
    }
    
    func getLockedSkins() -> [Skin] {
        return skins.filter { !unlockedSkins.contains($0.key) }.map { $0.value }
    }
    
    func getSkinsByRarity(_ rarity: String) -> [Skin] {
        return skins.values.filter { $0.getRarity() == rarity }
    }
    
    func isSkinUnlocked(_ skinId: String) -> Bool {
        return unlockedSkins.contains(skinId)
    }
    
    // MARK: - Progress Persistence
    private func saveSkinProgress() {
        let progress = SkinProgress(
            unlockedSkins: Array(unlockedSkins),
            currentSkinId: currentSkin?.getId()
        )
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(progress)
            UserDefaults.standard.set(data, forKey: "skinProgress")
        } catch {
            print("Error saving skin progress: \(error)")
        }
    }
    
    private func loadSkinProgress() {
        guard let data = UserDefaults.standard.data(forKey: "skinProgress"),
              let progress = try? JSONDecoder().decode(SkinProgress.self, from: data) else {
            return
        }
        
        unlockedSkins = Set(progress.unlockedSkins)
        if let currentSkinId = progress.currentSkinId {
            currentSkin = skins[currentSkinId]
        }
    }
}

// MARK: - Supporting Types
struct SkinInfo: Codable {
    let name: String
    let description: String
    let rarity: String
    let unlockCondition: UnlockCondition
    let visual: SkinVisuals
}

struct SkinProgress: Codable {
    let unlockedSkins: [String]
    let currentSkinId: String?
}

// MARK: - Notifications
extension Notification.Name {
    static let skinUnlocked = Notification.Name("skinUnlocked")
    static let skinEquipped = Notification.Name("skinEquipped")
}

// MARK: - Preview Helper
#if DEBUG
extension SkinManager {
    static var preview: SkinManager {
        let manager = SkinManager()
        // Add preview data here if needed
        return manager
    }
}
#endif
