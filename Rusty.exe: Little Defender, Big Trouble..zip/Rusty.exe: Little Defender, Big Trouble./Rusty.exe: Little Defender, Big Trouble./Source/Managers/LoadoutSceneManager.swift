// LoadoutSceneManager.swift

import Foundation

class LoadoutSceneManager {
    static let shared = LoadoutSceneManager()

    private let leftWeaponKey = "loadout_left_weapon_id"
    private let rightWeaponKey = "loadout_right_weapon_id"
    private let dualWieldUnlockedKey = "loadout_dual_wield_unlocked"

    private init() {}

    var selectedLeftWeaponID: String? {
        get { UserDefaults.standard.string(forKey: leftWeaponKey) }
        set { UserDefaults.standard.set(newValue, forKey: leftWeaponKey) }
    }

    var selectedRightWeaponID: String? {
        get { UserDefaults.standard.string(forKey: rightWeaponKey) }
        set { UserDefaults.standard.set(newValue, forKey: rightWeaponKey) }
    }

    var isDualWieldUnlocked: Bool {
        get { UserDefaults.standard.bool(forKey: dualWieldUnlockedKey) }
        set { UserDefaults.standard.set(newValue, forKey: dualWieldUnlockedKey) }
    }

    func saveLoadout(leftID: String?, rightID: String?) {
        selectedLeftWeaponID = leftID
        selectedRightWeaponID = rightID
    }

    func clearLoadout() {
        selectedLeftWeaponID = nil
        selectedRightWeaponID = nil
    }
}
