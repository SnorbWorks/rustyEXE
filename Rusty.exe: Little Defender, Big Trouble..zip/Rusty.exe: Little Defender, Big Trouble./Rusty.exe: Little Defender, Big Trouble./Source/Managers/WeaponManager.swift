import Foundation

class WeaponManager {
    static let shared = WeaponManager()

    private var ownedWeapons: [String: WeaponInfo] = [:]
    private var upgradeLevels: [String: [StatType: Int]] = [:]

    private let weaponsKey = "ownedWeapons"
    private let upgradesKey = "weaponUpgrades"

    private init() {
        load()
    }

    func load() {
        // Load weapons
        if let data = UserDefaults.standard.data(forKey: weaponsKey),
           let decoded = try? JSONDecoder().decode([String: WeaponInfo].self, from: data) {
            ownedWeapons = decoded
        }

        // Load upgrade levels
        if let data = UserDefaults.standard.data(forKey: upgradesKey),
           let decoded = try? JSONDecoder().decode([String: [StatType: Int]].self, from: data) {
            upgradeLevels = decoded
        }
    }

    func save() {
        if let data = try? JSONEncoder().encode(ownedWeapons) {
            UserDefaults.standard.set(data, forKey: weaponsKey)
        }

        if let data = try? JSONEncoder().encode(upgradeLevels) {
            UserDefaults.standard.set(data, forKey: upgradesKey)
        }
    }

    func getAllOwnedWeapons() -> [WeaponInfo] {
        return Array(ownedWeapons.values)
    }

    func isWeaponOwned(_ id: String) -> Bool {
        return ownedWeapons[id] != nil
    }

    func unlockWeapon(_ weapon: WeaponInfo) {
        ownedWeapons[weapon.name] = weapon
        save()
    }

    func getUpgradeLevel(for weaponId: String, stat: StatType) -> Int {
        return upgradeLevels[weaponId]?[stat] ?? 0
    }

    func upgradeWeapon(withId id: String, stat: StatType) -> Bool {
        guard var weapon = ownedWeapons[id],
              let levels = weapon.upgrades[stat],
              let currentLevel = upgradeLevels[id]?[stat] ?? 0 as Int?,
              currentLevel < levels.count else {
            return false
        }

        let nextLevel = currentLevel + 1
        let newValue = levels[currentLevel].value

        // Update baseStats
        switch stat {
        case .damage: weapon.baseStats.damage = newValue
        case .rateOfFire: weapon.baseStats.rateOfFire = newValue
        case .projectilesPerShot: weapon.baseStats.projectilesPerShot = Int(newValue)
        case .spread: weapon.baseStats.spread = newValue
        case .projectileSpeed: weapon.baseStats.projectileSpeed = newValue
        case .chargeTime: weapon.baseStats.chargeTime = newValue
        case .range: weapon.baseStats.range = newValue
        case .energyCost: weapon.baseStats.energyCost = newValue
        }

        ownedWeapons[id] = weapon
        if upgradeLevels[id] == nil {
            upgradeLevels[id] = [:]
        }
        upgradeLevels[id]?[stat] = nextLevel

        save()
        return true
    }

    func getWeaponInfo(for id: String) -> WeaponInfo? {
        return ownedWeapons[id]
    }
}
