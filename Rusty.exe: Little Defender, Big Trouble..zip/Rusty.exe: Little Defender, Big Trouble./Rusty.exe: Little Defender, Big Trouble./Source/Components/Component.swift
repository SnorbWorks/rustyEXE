// Component.swift
import Foundation

protocol Component {}
