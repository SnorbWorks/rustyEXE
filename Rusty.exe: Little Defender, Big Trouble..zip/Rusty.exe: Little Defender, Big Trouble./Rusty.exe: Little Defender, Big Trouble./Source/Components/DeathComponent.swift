// DeathComponent.swift
import Foundation

struct DeathComponent: Component {
    var isDead: Bool
}
