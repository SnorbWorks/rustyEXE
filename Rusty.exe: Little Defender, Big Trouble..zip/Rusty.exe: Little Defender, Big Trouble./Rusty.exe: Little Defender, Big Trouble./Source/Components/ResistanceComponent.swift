// ResistanceComponent.swift
import Foundation

struct ResistanceComponent: Component {
    var resistances: [ProjectileType: CGFloat]  // 0.0–1.0 scale (0 = no resistance, 1 = full immunity)
}
