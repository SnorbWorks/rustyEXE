// HealthComponent.swift
import Foundation

struct HealthComponent: Component {
    var currentHealth: CGFloat
    var maxHealth: CGFloat
}
