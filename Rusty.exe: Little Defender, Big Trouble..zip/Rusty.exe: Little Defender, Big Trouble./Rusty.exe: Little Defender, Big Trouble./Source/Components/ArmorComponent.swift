// ArmorComponent.swift
import Foundation

struct ArmorComponent: Component {
    var armorValue: CGFloat
}
