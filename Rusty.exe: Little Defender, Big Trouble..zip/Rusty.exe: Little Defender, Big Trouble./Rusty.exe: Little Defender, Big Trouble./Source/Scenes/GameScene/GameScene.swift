//
//  GameScene.swift
//  Rusty.exe: Little Defender, Big Trouble.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    static weak var sharedInstance: GameScene?

    private var lastFireTime: TimeInterval = 0
    private var player: SKSpriteNode!
    private var isTouching = false
    private var activeTouch: UITouch?
    private var enemyManager: EnemyManager!
    private var upgradeManager: UpgradeMilestoneManager!
    private var weaponAutoFireManager: WeaponAutoFireManager!
    private var weaponSelector: WeaponSelector!
    private var activeTurret: PaperclipTurret?

    var playerPosition: CGPoint {
        return player.position
    }

    private var playerIsDead = false
    private var isCharging = false
    private var chargeStartTime: TimeInterval = 0
    private var isCoolingDownFromCharge = false
    private var autoFireUnlocked = false

    private var currentScore = 0
    private var currentLevel = 1
    private var currentWave = 1
    private var waveInProgress = false
    private var isWaveComplete = false

    override func didMove(to view: SKView) {
        GameScene.sharedInstance = self
        physicsWorld.contactDelegate = self
        initializePlayer()
        enemyManager = EnemyManager(scene: self)
        upgradeManager = UpgradeMilestoneManager(scene: self)
        weaponAutoFireManager = WeaponAutoFireManager(scene: self)
        setupHUD()
    }

    private func initializePlayer() {
        player = SKSpriteNode(imageNamed: "player_ship")
        player.position = CGPoint(x: size.width / 2, y: size.height * 0.1)
        player.zPosition = 10
        player.name = "player"
        player.physicsBody = SKPhysicsBody(texture: player.texture!, size: player.size)
        player.physicsBody?.isDynamic = true
        player.physicsBody?.categoryBitMask = PhysicsCategory.player
        player.physicsBody?.contactTestBitMask = PhysicsCategory.enemy | PhysicsCategory.enemyProjectile
        player.physicsBody?.collisionBitMask = 0
        addChild(player)
    }

    private func setupHUD() {
        // Add your HUD elements like score, health bars, etc.
    }

    override func update(_ currentTime: TimeInterval) {
        if playerIsDead { return }
        weaponAutoFireManager.update(currentTime: currentTime)
        enemyManager.update(currentTime: currentTime)
        upgradeManager.update(score: currentScore)
    }

    override func didSimulatePhysics() {
        guard let touch = activeTouch else { return }
        let location = touch.location(in: self)
        let clampedX = max(size.width * 0.15, min(size.width * 0.85, location.x))
        player.position = CGPoint(x: clampedX, y: size.height * 0.1)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if activeTouch == nil {
            activeTouch = touches.first
            isTouching = true
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, touch == activeTouch {
            // Handle dragging logic if needed
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, touch == activeTouch {
            activeTouch = nil
            isTouching = false
        }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, touch == activeTouch {
            activeTouch = nil
            isTouching = false
        }
    }

    func increaseScore(by points: Int) {
        currentScore += points
    }

    func triggerGameOver() {
        playerIsDead = true
        // Display game over UI or transition
    }
}
