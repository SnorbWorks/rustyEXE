import SpriteKit
import GameplayKit

class SkinPreviewScene: SKScene {
    private var previewNode: SKSpriteNode?
    private var currentSkin: Skin?
    
    override func didMove(to view: SKView) {
        setupPreviewNode()
    }
    
    private func setupPreviewNode() {
        previewNode = SKSpriteNode(imageNamed: "player_base")
        if let previewNode = previewNode {
            previewNode.position = CGPoint(x: frame.midX, y: frame.midY)
            addChild(previewNode)
        }
    }
    
    func previewSkin(_ skin: Skin) {
        currentSkin = skin
        
        guard let previewNode = previewNode else { return }
        
        // Clear existing effects
        previewNode.removeAllChildren()
        previewNode.removeAllActions()
        
        // Apply new skin
        if let visualComponent = skin.component(ofType: SkinVisualComponent.self) {
            visualComponent.applyVisuals(to: previewNode)
            visualComponent.playAnimation(.idle)
        }
        
        if let effectComponent = skin.component(ofType: SkinEffectComponent.self) {
            effectComponent.applyEffects(to: previewNode)
        }
    }
    
    func playDeathAnimation() {
        guard let skin = currentSkin,
              let visualComponent = skin.component(ofType: SkinVisualComponent.self) else {
            return
        }
        
        visualComponent.playAnimation(.death)
    }
}
