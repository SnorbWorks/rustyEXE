import SpriteKit

class LoadoutScene_Weapons: SKScene {
    
    private var leftCarousel: WeaponCarouselNode!
    private var rightCarousel: WeaponCarouselNode!
    private var rustyNode: SKSpriteNode!
    private var weaponStatsBox: SKLabelNode!
    private var currentLeftWeapon: WeaponInfo?
    private var currentRightWeapon: WeaponInfo?

    override func didMove(to view: SKView) {
        backgroundColor = .black
        setupUI()
        loadWeaponData()
        NotificationCenter.default.addObserver(self, selector: #selector(refresh), name: .refreshLoadoutScene, object: nil)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupUI() {
        addHeader()
        addRustyNode()
        addCarousels()
        addPlayButton()
    }

    private func addHeader() {
        let title = SKLabelNode(text: "LOADOUT")
        title.fontName = "AvenirNext-Bold"
        title.fontSize = 48
        title.position = CGPoint(x: frame.midX, y: frame.maxY - 100)
        addChild(title)
        
        let weaponsLabel = SKLabelNode(text: ">WEAPONS<")
        weaponsLabel.fontSize = 24
        weaponsLabel.position = CGPoint(x: frame.midX, y: frame.maxY - 150)
        addChild(weaponsLabel)
    }

    private func addRustyNode() {
        rustyNode = SKSpriteNode(imageNamed: "rusty_base")
        rustyNode.position = CGPoint(x: frame.midX, y: frame.midY)
        rustyNode.setScale(1.0)
        addChild(rustyNode)
    }

    private func addCarousels() {
        leftCarousel = WeaponCarouselNode(isLeft: true)
        rightCarousel = WeaponCarouselNode(isLeft: false)
        
        leftCarousel.position = CGPoint(x: frame.midX - 180, y: frame.midY)
        rightCarousel.position = CGPoint(x: frame.midX + 180, y: frame.midY)

        leftCarousel.delegate = self
        rightCarousel.delegate = self
        
        addChild(leftCarousel)
        addChild(rightCarousel)
    }

    private func addPlayButton() {
        let playButton = SKLabelNode(text: "PLAY")
        playButton.name = "play_button"
        playButton.fontSize = 36
        playButton.position = CGPoint(x: frame.midX, y: frame.minY + 100)
        addChild(playButton)
    }

    private func loadWeaponData() {
        let weapons = WeaponRepository.shared.getAllWeapons()
        leftCarousel.loadWeapons(weapons)
        rightCarousel.loadWeapons(weapons)
    }

    private func updateStatsDisplay(with weapon: WeaponInfo) {
        weaponStatsBox?.removeFromParent()

        let label = SKLabelNode(fontNamed: "AvenirNext-Bold")
        label.fontSize = 18
        label.position = CGPoint(x: frame.midX, y: frame.minY + 200)
        label.numberOfLines = 0
        label.preferredMaxLayoutWidth = 300
        label.horizontalAlignmentMode = .center
        label.verticalAlignmentMode = .top

        let damage = weapon.baseStats.damage
        let rate = weapon.baseStats.rateOfFire ?? 0
        let energy = weapon.baseStats.energyCost ?? 0

        var upgradeNotice = ""
        if !weapon.upgrades.isEmpty {
            upgradeNotice = "\n>> UPDATE AVAILABLE <<"
        }

        label.text = """
        \(weapon.name)
        Dmg: \(Int(damage)) | RoF: \(rate) | Energy: \(Int(energy))\(upgradeNotice)
        """

        weaponStatsBox = label
        addChild(label)
    }

    private func updateRustyVisual(for weapon: WeaponInfo, isLeft: Bool) {
        let attachmentName = weapon.name + (isLeft ? "_left" : "_right")
        print("Rusty equipped: \(attachmentName)")
        // TODO: Replace placeholder with real sprite attachment logic
    }
    
    // MARK: - Selection Saving
    
    func weaponCarousel(_ carousel: WeaponCarouselNode, didSelect weapon: WeaponInfo) {
        updateStatsDisplay(with: weapon)

        if carousel == leftCarousel {
            currentLeftWeapon = weapon
            PlayerManager.shared.equipWeapon(id: weapon.id, isLeft: true)
            updateRustyVisual(for: weapon, isLeft: true)
        } else {
            currentRightWeapon = weapon
            PlayerManager.shared.equipWeapon(id: weapon.id, isLeft: false)
            updateRustyVisual(for: weapon, isLeft: false)
        }
    }

    // MARK: - Refresh Handling
    @objc func refresh() {
        leftCarousel.clear()
        rightCarousel.clear()
        
        let weapons = WeaponRepository.shared.getAllWeapons()
        leftCarousel.loadWeapons(weapons)
        rightCarousel.loadWeapons(weapons)

        if let left = WeaponManager.shared.getEquippedWeapon(side: .left) {
            leftCarousel.selectWeapon(left)
        }

        if let right = WeaponManager.shared.getEquippedWeapon(side: .right) {
            rightCarousel.selectWeapon(right)
        }
    }
}

// MARK: - UpgradeOverlay

private func showUpgradeOverlay(for weapon: WeaponInfo) {
    let overlay = UpgradeOverlay(for: weapon, currentGems: PlayerManager.shared.getGemBalance())
    overlay.position = CGPoint(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
    
    overlay.onDismiss = {
        overlay.removeFromParent()
    }

    overlay.onPurchase = { stat in
        let cost = weapon.upgrades[stat]?[0].requirement.gems ?? 0
        if PlayerManager.shared.spendGems(cost),
           WeaponManager.shared.upgradeWeapon(withId: weapon.name, stat: stat) {
            NotificationCenter.default.post(name: .refreshLoadoutScene, object: nil)
        }
    }

    UIApplication.shared.windows.first?.rootViewController?.view?.addSubview(overlay.view)
}

// MARK: - WeaponCarouselDelegate

extension LoadoutScene_Weapons: WeaponCarouselDelegate {
    func weaponCarousel(_ carousel: WeaponCarouselNode, didSelect weapon: WeaponInfo) {
        updateStatsDisplay(with: weapon)

        if carousel == leftCarousel {
            currentLeftWeapon = weapon
            updateRustyVisual(for: weapon, isLeft: true)
        } else {
            currentRightWeapon = weapon
            updateRustyVisual(for: weapon, isLeft: false)
        }
    }
}
