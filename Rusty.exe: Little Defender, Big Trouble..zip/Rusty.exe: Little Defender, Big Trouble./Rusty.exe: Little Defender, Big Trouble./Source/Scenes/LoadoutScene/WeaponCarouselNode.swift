import SpriteKit

protocol WeaponCarouselDelegate: AnyObject {
    func weaponCarousel(_ carousel: WeaponCarouselNode, didSelect weapon: WeaponInfo)
}

class WeaponCarouselNode: SKNode {
    
    private let isLeft: Bool
    private var weapons: [WeaponInfo] = []
    private var displayNodes: [SKSpriteNode] = []
    private var currentSelectionIndex: Int = 0
    private let spacing: CGFloat = 100
    weak var delegate: WeaponCarouselDelegate?
    
    private var isEnabled: Bool = true
    
    init(isLeft: Bool) {
        self.isLeft = isLeft
        super.init()
        
        if !isLeft && !PlayerManager.shared.isDualWieldUnlocked() {
            isEnabled = false
            self.alpha = 0.3
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func loadWeapons(_ weapons: [WeaponInfo]) {
        self.weapons = weapons
        layoutWeapons()
    }
    
    private func layoutWeapons() {
        displayNodes.forEach { $0.removeFromParent() }
        displayNodes = []
        
        for (index, weapon) in weapons.enumerated() {
            let node = SKSpriteNode(imageNamed: weapon.name)
            node.name = weapon.name
            node.position = CGPoint(x: CGFloat(index) * spacing, y: 0)
            
            if !PlayerManager.shared.isWeaponUnlocked(weapon.id) {
                node.alpha = 0.3
                node.color = .gray
                node.colorBlendFactor = 0.6
                
                let lockLabel = SKLabelNode(text: "LOCKED")
                lockLabel.fontSize = 14
                lockLabel.fontName = "AvenirNext-Bold"
                lockLabel.fontColor = .red
                lockLabel.position = CGPoint(x: 0, y: -40)
                node.addChild(lockLabel)
            }
            
            displayNodes.append(node)
            addChild(node)
        }
        
        updateSelection()
    }
    
    private func updateSelection() {
        for (index, node) in displayNodes.enumerated() {
            node.setScale(index == currentSelectionIndex ? 1.2 : 1.0)
        }
        
        if weapons.indices.contains(currentSelectionIndex),
           PlayerManager.shared.isWeaponUnlocked(weapons[currentSelectionIndex].id) {
            delegate?.weaponCarousel(self, didSelect: weapons[currentSelectionIndex])
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard isEnabled else { return }
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        for (index, node) in displayNodes.enumerated() {
            if node.contains(location) {
                let selectedWeapon = weapons[index]
                if PlayerManager.shared.isWeaponUnlocked(selectedWeapon.id) {
                    currentSelectionIndex = index
                    updateSelection()
                }
            }
        }
    }
    
    func selectWeapon(_ weapon: WeaponInfo) {
        if let index = weapons.firstIndex(where: { $0.id == weapon.id }) {
            currentSelectionIndex = index
            updateSelection()
        }
    }
    
    func clear() {
        weapons = []
        displayNodes.forEach { $0.removeFromParent() }
        displayNodes.removeAll()
        currentSelectionIndex = 0
    }
    
    func refresh() {
        layoutWeapons()
        
        // Correct selection if current index is now locked or invalid
        if weapons.indices.contains(currentSelectionIndex),
           !PlayerManager.shared.isWeaponUnlocked(weapons[currentSelectionIndex].id) {
            if let firstUnlocked = weapons.firstIndex(where: { PlayerManager.shared.isWeaponUnlocked($0.id) }) {
                currentSelectionIndex = firstUnlocked
            } else {
                currentSelectionIndex = 0
            }
        }
        
        updateSelection()
    }
}
