// CurrencyTransaction.swift
import Foundation

struct CurrencyTransaction: Codable {
    let id: UUID
    let type: TransactionType
    let amount: Int
    let timestamp: Date
    let source: TransactionSource
    let itemId: String?  // If transaction is related to an item
    
    enum TransactionType: String, Codable {
        case pointsEarned
        case pointsSpent
        case gemsEarned
        case gemsSpent
        case gemsPurchased
    }
    
    enum TransactionSource: String, Codable {
        case gameplay
        case achievement
        case purchase
        case store
        case reward
        case dailyBonus
    }
}

struct CurrencyBalance: Codable {
    var points: Int
    var gems: Int
    var lifetimePoints: Int
    var lifetimeGems: Int
    var transactions: [CurrencyTransaction]
    
    mutating func add(points: Int, source: CurrencyTransaction.TransactionSource) {
        self.points += points
        self.lifetimePoints += max(0, points)
        recordTransaction(.pointsEarned, amount: points, source: source)
    }
    
    mutating func add(gems: Int, source: CurrencyTransaction.TransactionSource) {
        self.gems += gems
        self.lifetimeGems += max(0, gems)
        recordTransaction(.gemsEarned, amount: gems, source: source)
    }
    
    private mutating func recordTransaction(
        _ type: CurrencyTransaction.TransactionType,
        amount: Int,
        source: CurrencyTransaction.TransactionSource,
        itemId: String? = nil
    ) {
        let transaction = CurrencyTransaction(
            id: UUID(),
            type: type,
            amount: amount,
            timestamp: Date(),
            source: source,
            itemId: itemId
        )
        transactions.append(transaction)
    }
}
