// GemPackage.swift
import StoreKit

struct GemPackage: Codable {
    let id: String
    let productId: String  // StoreKit product identifier
    let gemAmount: Int
    let bonusAmount: Int
    let price: Decimal
    let name: String
    let description: String
    
    var totalGems: Int {
        return gemAmount + bonusAmount
    }
}
