import Foundation

struct Currency: Codable, Equatable {
    var points: Int
    var gems: Int
    
    static var zero: Currency {
        return Currency(points: 0, gems: 0)
    }
    
    func canAfford(_ requirement: CurrencyRequirement) -> Bool {
        switch requirement {
        case .points(let reqPoints): return points >= reqPoints
        case .gems(let reqGems): return gems >= reqGems
        }
    }
}
