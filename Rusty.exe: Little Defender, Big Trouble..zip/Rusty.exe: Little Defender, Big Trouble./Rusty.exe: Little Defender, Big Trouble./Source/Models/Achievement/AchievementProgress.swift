// AchievementProgress.swift
import Foundation

struct AchievementProgress: Codable {
    var unlockedAchievements: Set<String>
    var progressMap: [String: Double]
    var killStreaks: [KillStreak]
    var highestLevel: Int
    var totalKills: Int
    var totalPoints: Int
    var perfectWaves: Int
    var longestSurvivalTime: TimeInterval
    
    mutating func updateProgress(for achievementId: String, progress: Double) {
        progressMap[achievementId] = min(max(progress, 0.0), 1.0)
    }
}
