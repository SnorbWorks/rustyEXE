// Achievement.swift
import Foundation

struct Achievement: Codable {
    let id: String
    let name: String
    let description: String
    let type: AchievementType
    let requirement: AchievementRequirement
    let rewards: AchievementRewards
    var isUnlocked: Bool = false
    var progress: Double = 0.0  // 0.0 to 1.0
    
    enum AchievementType: String, Codable {
        case killCount
        case levelReached
        case killStreak
        case pointsEarned
        case perfectWave      // Complete wave without taking damage
        case survivalTime
        case weaponMastery
        case shieldMastery
    }
}

struct AchievementRequirement: Codable {
    let type: RequirementType
    let value: Int
    let timeFrame: TimeInterval?  // For time-based requirements
    
    enum RequirementType: String, Codable {
        case kills
        case level
        case streakKills
        case points
        case waves
        case time
        case weaponKills
        case shieldBlocks
    }
}

struct AchievementRewards: Codable {
    let points: Int
    let gems: Int
    let unlocks: [UnlockReward]
    
    struct UnlockReward: Codable {
        let type: UnlockType
        let id: String
        
        enum UnlockType: String, Codable {
            case weapon
            case shield
            case patch
            case skin
        }
    }
}
