// KillStreak.swift
import Foundation

struct KillStreak: Codable {
    let id: UUID
    let kills: Int
    let timeFrame: TimeInterval
    let timestamp: Date
    
    var isActive: Bool {
        return Date().timeIntervalSince(timestamp) <= timeFrame
    }
}
