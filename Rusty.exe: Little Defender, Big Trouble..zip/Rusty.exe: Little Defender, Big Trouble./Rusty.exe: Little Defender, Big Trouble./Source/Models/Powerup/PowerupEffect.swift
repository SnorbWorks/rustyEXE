// PowerupEffect.swift
import Foundation

struct PowerupEffect: Codable {
    let type: EffectType
    let value: Double
    
    enum EffectType: String, Codable {
        case damageMultiplier
        case fireRateMultiplier
        case healthRegeneration
        case shieldRegeneration
        case movementSpeed
        case projectileSize
        case projectileCount
        case projectileSpeed
        case areaEffect
    }
}
