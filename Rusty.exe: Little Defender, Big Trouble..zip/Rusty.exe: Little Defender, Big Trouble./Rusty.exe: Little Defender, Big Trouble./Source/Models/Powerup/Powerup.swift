// Powerup.swift
import Foundation

struct Powerup: Codable {
    let id: UUID
    let type: PowerupType
    let duration: TimeInterval
    let effects: [PowerupEffect]
    let startTime: Date
    
    var isExpired: Bool {
        return Date().timeIntervalSince(startTime) >= duration
    }
    
    var remainingTime: TimeInterval {
        let elapsed = Date().timeIntervalSince(startTime)
        return max(0, duration - elapsed)
    }
}
