// PowerupType.swift
import Foundation

enum PowerupType: String, Codable {
    case damageBoost
    case fireRateBoost
    case multiShot
    case shieldRecharge
    case healthRegeneration
    case timeSlow
    case projectileEnhancement
    case areaEffect
    
    var defaultDuration: TimeInterval {
        switch self {
        case .damageBoost: return 10.0
        case .fireRateBoost: return 8.0
        case .multiShot: return 15.0
        case .shieldRecharge: return 5.0
        case .healthRegeneration: return 5.0
        case .timeSlow: return 6.0
        case .projectileEnhancement: return 12.0
        case .areaEffect: return 8.0
        }
    }
    
    var effects: [PowerupEffect] {
        switch self {
        case .damageBoost:
            return [PowerupEffect(type: .damageMultiplier, value: 2.0)]
        case .fireRateBoost:
            return [PowerupEffect(type: .fireRateMultiplier, value: 1.5)]
        case .multiShot:
            return [PowerupEffect(type: .projectileCount, value: 2.0)]
        case .shieldRecharge:
            return [PowerupEffect(type: .shieldRegeneration, value: 10.0)]
        case .healthRegeneration:
            return [PowerupEffect(type: .healthRegeneration, value: 5.0)]
        case .timeSlow:
            return [PowerupEffect(type: .movementSpeed, value: 0.5)]
        case .projectileEnhancement:
            return [
                PowerupEffect(type: .projectileSize, value: 1.5),
                PowerupEffect(type: .projectileSpeed, value: 1.3)
            ]
        case .areaEffect:
            return [PowerupEffect(type: .areaEffect, value: 1.5)]
        }
    }
}
