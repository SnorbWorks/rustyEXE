import Foundation
import CoreGraphics
import SpriteKit

// MARK: - Game Types
enum GameDifficulty {
    case easy
    case normal
    case hard
    case endless
}

// MARK: - Weapon Types
enum WeaponType: String, Codable {
    case auto
    case burst
    case charge
    case beam
    case summon
    case targeted
}

enum ProjectileBehavior: String, Codable {
    case straight
    case homing
    case wave
    case chain
    case field
    case continuous
    case autonomous
    case orbital
    case spiral
    case scatter
}

enum ProjectileType: String, Codable {
    case energy
    case explosive
    case quantum
    case lightning
    case gravity
    case temporal
    case plasma
    case drone
}

// MARK: - Shield Types
enum ShieldType: String, Codable {
    case static_
    case pulse
    case field
    case hybrid
    case enhancer
}

enum ShieldBehavior: String, Codable {
    case block
    case push
    case slow
    case consume
    case reflect
    case redirect
    case adapt
    case combine
}

// MARK: - Patch Types
enum PatchType: String, Codable {
    case deathTrigger
    case healthTrigger
    case passive
}

enum TriggerCondition: Codable {
    case death
    case healthThreshold(percentage: CGFloat)
    case killStreak(count: Int, timeFrame: TimeInterval)
    case damageThreshold(amount: CGFloat)
}

// MARK: - Visual Effects
enum VisualEffectType: String, Codable {
    case deploy
    case active
    case damage
    case destroy
}

enum ParticleEffectType: String, Codable {
    // Weapon effects
    case energyBolt
    case explosion
    case quantumRift
    case lightningArc
    case gravityWell
    case timeDistortion
    case plasmaBurst
    case droneTrail

    // Shield effects
    case energyRipple
    case shockwave
    case chronoShift
    case voidRift
    case mirrorShimmer
    case resonancePulse
    case vortexSpin

    // Patch effects
    case rageMist
    case emergencyPower
    case overclockedSteam
    case adaptiveShimmer
}

// MARK: - Rarity
enum Rarity: String, Codable {
    case common
    case uncommon
    case rare
    case epic
    case legendary
    case mythic

    var color: String {
        switch self {
        case .common: return "#ffffff"
        case .uncommon: return "#1eff00"
        case .rare: return "#0070dd"
        case .epic: return "#a335ee"
        case .legendary: return "#ff8000"
        case .mythic: return "#ff0000"
        }
    }
}

// MARK: - Stats
enum StatType: String, Codable {
    case health, damage, rateOfFire, speed, range, radius, duration, cooldown
    case projectileSpeed, projectileCount, spread, penetration, chargeTime, explosionRadius
    case chainCount, turnRate, accuracy, reloadSpeed, magazineSize, burstCount, burstDelay
    case regenerationRate, deployTime, resistanceAmount, reflectionAngle, pushForce
    case absorptionRate, shieldCapacity, rechargeDelay, deflectionChance
    case effectPower, triggerChance, conversionRate, criticalChance, criticalMultiplier
    case procRate, stackLimit
    case energyCost, energyGeneration, gemBonus, pointMultiplier, resourceEfficiency
    case damageMultiplier, speedMultiplier, rangeMultiplier, durationMultiplier
    case cooldownReduction, areaMultiplier, effectMultiplier
    case chainEfficiency, fieldStrength, timeWarpFactor, dimensionalPower, quantumStability
    case energyDamageMultiplier, explosiveDamageMultiplier  // ✅ ADDED

    var displayName: String {
        switch self {
        case .health: return "Health"
        case .damage: return "Damage"
        case .rateOfFire: return "Rate of Fire"
        case .speed: return "Speed"
        case .range: return "Range"
        case .radius: return "Radius"
        case .duration: return "Duration"
        case .cooldown: return "Cooldown"
        default: return self.rawValue.capitalized
        }
    }

    var format: String {
        switch self {
        case .health, .damage, .radius, .range: return "%.0f"
        case .rateOfFire, .speed: return "%.2f"
        case .duration, .cooldown: return "%.1fs"
        case .damageMultiplier, .speedMultiplier, .criticalChance,
             .energyDamageMultiplier, .explosiveDamageMultiplier: return "+%.0f%%"
        case .energyCost: return "%.1f/s"
        default: return "%.1f"
        }
    }

    var defaultValue: CGFloat {
        switch self {
        case .health: return 100
        case .damage: return 10
        case .rateOfFire: return 1.0
        case .speed: return 100
        case .range: return 500
        case .radius: return 50
        case .duration: return 5
        case .cooldown: return 1
        case .energyCost: return 1
        default: return 0
        }
    }

    var maxValue: CGFloat {
        switch self {
        case .health: return 1000
        case .damage: return 500
        case .rateOfFire: return 10.0
        case .speed: return 500
        case .range: return 2000
        case .radius: return 300
        case .duration: return 30
        case .cooldown: return 60
        case .damageMultiplier, .energyDamageMultiplier, .explosiveDamageMultiplier: return 5.0
        default: return 1000
        }
    }

    var isPercentage: Bool {
        switch self {
        case .criticalChance, .damageMultiplier, .speedMultiplier,
             .rangeMultiplier, .durationMultiplier, .cooldownReduction,
             .effectMultiplier, .resourceEfficiency,
             .energyDamageMultiplier, .explosiveDamageMultiplier:
            return true
        default:
            return false
        }
    }

    var category: StatCategory {
        switch self {
        case .health, .damage, .rateOfFire, .speed, .range, .radius, .duration, .cooldown:
            return .core
        case .projectileSpeed, .projectileCount, .spread, .penetration, .chargeTime,
             .explosionRadius, .chainCount, .turnRate, .accuracy, .reloadSpeed,
             .magazineSize, .burstCount, .burstDelay:
            return .weapon
        case .regenerationRate, .deployTime, .resistanceAmount, .reflectionAngle,
             .pushForce, .absorptionRate, .shieldCapacity, .rechargeDelay,
             .deflectionChance:
            return .shield
        case .effectPower, .triggerChance, .conversionRate, .criticalChance,
             .criticalMultiplier, .procRate, .stackLimit:
            return .patch
        case .energyCost, .energyGeneration, .gemBonus, .pointMultiplier,
             .resourceEfficiency:
            return .resource
        case .damageMultiplier, .speedMultiplier, .rangeMultiplier,
             .durationMultiplier, .cooldownReduction, .areaMultiplier,
             .effectMultiplier, .energyDamageMultiplier, .explosiveDamageMultiplier:
            return .multiplier
        case .chainEfficiency, .fieldStrength, .timeWarpFactor,
             .dimensionalPower, .quantumStability:
            return .special
        }
    }
}

enum StatCategory {
    case core, weapon, shield, patch, resource, multiplier, special
}

// MARK: - Currency Requirement (added)
enum CurrencyRequirement: Codable, Equatable {
    case points(Int)
    case gems(Int)

    private enum CodingKeys: String, CodingKey {
        case type, value
    }

    private enum RequirementType: String, Codable {
        case points, gems
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let type = try container.decode(RequirementType.self, forKey: .type)
        let value = try container.decode(Int.self, forKey: .value)

        switch type {
        case .points: self = .points(value)
        case .gems: self = .gems(value)
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .points(let value):
            try container.encode(RequirementType.points, forKey: .type)
            try container.encode(value, forKey: .value)
        case .gems(let value):
            try container.encode(RequirementType.gems, forKey: .type)
            try container.encode(value, forKey: .value)
        }
    }
}

// MARK: - Achievements
enum AchievementType: String, Codable {
    case killCount, levelReached, killStreak, pointsEarned, perfectWave
    case survivalTime, weaponMastery, shieldMastery
}

// MARK: - Error Handling
enum GameError: Error {
    case insufficientFunds, alreadyUnlocked, notUnlocked, maxEquipped
    case invalidId, saveFailed, loadFailed
}

// MARK: - Notification Keys
extension Notification.Name {
    static let refreshLoadoutScene = Notification.Name("refreshLoadoutScene")
}
