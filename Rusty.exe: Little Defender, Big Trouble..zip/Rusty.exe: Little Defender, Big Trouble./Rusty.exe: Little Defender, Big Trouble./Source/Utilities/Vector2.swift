import GameplayKit

class Vector2 {
    var point: CGPoint
    
    init(x: CGFloat, y: CGFloat) {
        self.point = CGPoint(x: x, y: y)
    }
    
    init(point: CGPoint) {
        self.point = point
    }
    
    var x: CGFloat {
        get { return point.x }
        set { point.x = newValue }
    }
    
    var y: CGFloat {
        get { return point.y }
        set { point.y = newValue }
    }
    
    func add(_ other: Vector2) -> Vector2 {
        return Vector2(x: self.x + other.x, y: self.y + other.y)
    }
    
    func subtract(_ other: Vector2) -> Vector2 {
        return Vector2(x: self.x - other.x, y: self.y - other.y)
    }
    
    func multiply(_ scalar: CGFloat) -> Vector2 {
        return Vector2(x: self.x * scalar, y: self.y * scalar)
    }
    
    func normalize() -> Vector2 {
        let magnitude = self.magnitude()
        if magnitude == 0 { return Vector2(x: 0, y: 0) }
        return self.multiply(1.0 / magnitude)
    }
    
    func magnitude() -> CGFloat {
        return sqrt(x * x + y * y)
    }
    
    func distance(to other: Vector2) -> CGFloat {
        return self.subtract(other).magnitude()
    }
    
    func angle() -> CGFloat {
        return atan2(y, x)
    }
    
    func rotate(by angle: CGFloat) -> Vector2 {
        let cos = cos(angle)
        let sin = sin(angle)
        return Vector2(
            x: x * cos - y * sin,
            y: x * sin + y * cos
        )
    }
    
    // Convert to vector types used by GameplayKit
    func toVector2D() -> vector_float2 {
        return vector_float2(Float(x), Float(y))
    }
    
    func toGKVector() -> GKVector2D {
        return GKVector2D(vector: self.toVector2D())
    }
    
    // Create from GameplayKit vector types
    static func fromGKVector(_ vector: GKVector2D) -> Vector2 {
        return Vector2(x: CGFloat(vector.x), y: CGFloat(vector.y))
    }
    
    static func fromVector2D(_ vector: vector_float2) -> Vector2 {
        return Vector2(x: CGFloat(vector.x), y: CGFloat(vector.y))
    }
}
