// WeaponRepository.swift

import Foundation
import GameplayKit

class WeaponRepository {
    static let shared = WeaponRepository()
    private(set) var weapons: [WeaponInfo] = []

    private init() {
        loadWeapons()
    }

    private func loadWeapons() {
        guard let url = Bundle.main.url(forResource: "weapons", withExtension: "json") else {
            print("❌ weapons.json not found.")
            return
        }

        do {
            let data = try Data(contentsOf: url)
            let wrapper = try JSONDecoder().decode(WeaponListWrapper.self, from: data)

            self.weapons = wrapper.weapons.map { key, value in
                var modified = value
                modified = WeaponInfo(
                    id: key,
                    name: value.name,
                    type: value.type,
                    projectileBehavior: value.projectileBehavior,
                    projectileType: value.projectileType,
                    weaponDescription: value.weaponDescription,
                    baseStats: value.baseStats,
                    upgrades: value.upgrades,
                    premium: value.premium
                )
                return modified
            }

            print("✅ Loaded \(weapons.count) weapons.")
        } catch {
            print("❌ Failed to load weapons.json:", error)
        }
    }

    func getAllWeapons() -> [WeaponInfo] {
        return weapons
    }

    func getWeaponInfo(byId id: String) -> WeaponInfo? {
        return weapons.first(where: { $0.id == id })
    }

    func getWeapon(byName name: String) -> WeaponInfo? {
        return weapons.first(where: { $0.name == name })
    }

    func createWeaponEntity(from info: WeaponInfo) -> Weapon {
        return Weapon(
            id: info.id,
            name: info.name,
            type: info.type,
            projectileBehavior: info.projectileBehavior,
            projectileType: info.projectileType,
            weaponDescription: info.weaponDescription,
            rarity: .common, // ✅ Injected default
            baseStats: info.baseStats,
            upgrades: convertUpgradeMap(info.upgrades),
            premium: info.premium ?? false
        )
    }

    func createWeaponEntity(byId id: String) -> Weapon? {
        guard let info = getWeaponInfo(byId: id) else { return nil }
        return createWeaponEntity(from: info)
    }

    private func convertUpgradeMap(_ raw: [String: [UpgradeLevel]]) -> [StatType: [UpgradeLevel]] {
        var result: [StatType: [UpgradeLevel]] = [:]
        for (key, levels) in raw {
            if let stat = StatType(rawValue: key) {
                result[stat] = levels
            }
        }
        return result
    }
}

private struct WeaponListWrapper: Codable {
    let weapons: [String: WeaponInfo]
}
