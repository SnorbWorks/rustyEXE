import GameplayKit

// MARK: - Supporting Structures
struct SkinVisuals: Codable {
    let baseColor: String
    let glowColor: String
    let particleEffect: String
    let deathAnimation: String
    let idleAnimation: String
    let scale: CGFloat
    let additionalEffects: [String: Bool]?
}

struct UnlockCondition: Codable {
    let type: String
    let requirement: UnlockRequirement
    let timeFrame: Int?
    
    enum CodingKeys: String, CodingKey {
        case type, requirement, timeFrame
    }
}

// Custom type to handle different requirement types (Int, Bool, Dictionary)
enum UnlockRequirement: Codable {
    case numeric(Int)
    case boolean(Bool)
    case premium([String: Int])
    case defaultSkin
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let intValue = try? container.decode(Int.self) {
            self = .numeric(intValue)
        } else if let boolValue = try? container.decode(Bool.self) {
            self = .boolean(boolValue)
        } else if let dictValue = try? container.decode([String: Int].self) {
            self = .premium(dictValue)
        } else if let stringValue = try? container.decode(String.self), stringValue == "default" {
            self = .defaultSkin
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Unable to decode requirement")
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .numeric(let value):
            try container.encode(value)
        case .boolean(let value):
            try container.encode(value)
        case .premium(let value):
            try container.encode(value)
        case .defaultSkin:
            try container.encode("default")
        }
    }
}

// MARK: - Skin Class
class Skin: GKEntity {
    // MARK: - Properties
    private let id: String
    private let name: String
    private let description: String
    private let rarity: String
    private let unlockCondition: UnlockCondition
    private let visual: SkinVisuals
    private var isUnlocked: Bool
    
    // MARK: - Components
    private lazy var visualComponent: SkinVisualComponent = {
        let component = SkinVisualComponent(visuals: visual)
        return component
    }()
    
    private lazy var effectComponent: SkinEffectComponent = {
        let component = SkinEffectComponent(effects: visual.additionalEffects ?? [:])
        return component
    }()
    
    // MARK: - Initialization
    init(id: String,
         name: String,
         description: String,
         rarity: String,
         unlockCondition: UnlockCondition,
         visual: SkinVisuals) {
        
        self.id = id
        self.name = name
        self.description = description
        self.rarity = rarity
        self.unlockCondition = unlockCondition
        self.visual = visual
        self.isUnlocked = unlockCondition.type == "default"
        
        super.init()
        
        addComponent(visualComponent)
        addComponent(effectComponent)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Public Methods
    func checkUnlockCondition(playerStats: PlayerStats) -> Bool {
        switch unlockCondition.type {
        case "default":
            return true
        case "enemiesDefeated":
            if case .numeric(let requirement) = unlockCondition.requirement {
                return playerStats.enemiesDefeated >= requirement
            }
        case "levelReached":
            if case .numeric(let requirement) = unlockCondition.requirement {
                return playerStats.level >= requirement
            }
        case "killStreak":
            if case .numeric(let requirement) = unlockCondition.requirement,
               let timeFrame = unlockCondition.timeFrame {
                return playerStats.checkKillStreak(kills: requirement, timeFrame: timeFrame)
            }
        case "perfectLevels":
            if case .numeric(let requirement) = unlockCondition.requirement {
                return playerStats.perfectLevels >= requirement
            }
        case "allAchievements":
            if case .boolean(let requirement) = unlockCondition.requirement {
                return requirement && playerStats.hasAllAchievements
            }
        case "premium":
            if case .premium(let requirement) = unlockCondition.requirement {
                return playerStats.hasRequiredGems(requirement["gems"] ?? 0)
            }
        default:
            return false
        }
        return false
    }
    
    func unlock() {
        isUnlocked = true
    }
    
    // MARK: - Getters
    func getId() -> String { return id }
    func getName() -> String { return name }
    func getRarity() -> String { return rarity }
    func isAvailable() -> Bool { return isUnlocked }
}

// MARK: - Components
class SkinVisualComponent: GKComponent {
    private let visuals: SkinVisuals
    private var currentAnimation: String?
    
    init(visuals: SkinVisuals) {
        self.visuals = visuals
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyVisuals(to node: SKNode) {
        // Apply color
        if let colorNode = node as? SKSpriteNode {
            colorNode.color = UIColor(hex: visuals.baseColor)
            colorNode.colorBlendFactor = 1.0
            colorNode.setScale(visuals.scale)
        }
        
        // Apply glow
        if visuals.glowColor != "rainbow" {
            applyGlowEffect(to: node, color: UIColor(hex: visuals.glowColor))
        } else {
            applyRainbowEffect(to: node)
        }
        
        // Apply particle effect
        addParticleEffect(to: node)
    }
    
    func playAnimation(_ type: AnimationType) {
        switch type {
        case .idle:
            playIdleAnimation()
        case .death:
            playDeathAnimation()
        }
    }
    
    private func applyGlowEffect(to node: SKNode, color: UIColor) {
        // Implementation
    }
    
    private func applyRainbowEffect(to node: SKNode) {
        // Implementation
    }
    
    private func addParticleEffect(to node: SKNode) {
        // Implementation
    }
    
    private func playIdleAnimation() {
        // Implementation
    }
    
    private func playDeathAnimation() {
        // Implementation
    }
}

class SkinEffectComponent: GKComponent {
    private let effects: [String: Bool]
    
    init(effects: [String: Bool]) {
        self.effects = effects
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyEffects(to node: SKNode) {
        effects.forEach { effect, enabled in
            if enabled {
                applyEffect(effect, to: node)
            }
        }
    }
    
    private func applyEffect(_ effect: String, to node: SKNode) {
        switch effect {
        case "motionBlur":
            applyMotionBlur(to: node)
        case "afterImage":
            applyAfterImage(to: node)
        case "environmentalGlow":
            applyEnvironmentalGlow(to: node)
        case "prismaticAura":
            applyPrismaticAura(to: node)
        // Add other effects
        default:
            break
        }
    }
    
    // Effect implementations
    private func applyMotionBlur(to node: SKNode) {
        // Implementation
    }
    
    private func applyAfterImage(to node: SKNode) {
        // Implementation
    }
    
    private func applyEnvironmentalGlow(to node: SKNode) {
        // Implementation
    }
    
    private func applyPrismaticAura(to node: SKNode) {
        // Implementation
    }
}

// MARK: - Supporting Types
enum AnimationType {
    case idle
    case death
}

struct PlayerStats {
    var enemiesDefeated: Int = 0
    var level: Int = 1
    var perfectLevels: Int = 0
    var hasAllAchievements: Bool = false
    var gems: Int = 0
    
    func checkKillStreak(kills: Int, timeFrame: Int) -> Bool {
        // Implementation
        return false
    }
    
    func hasRequiredGems(_ amount: Int) -> Bool {
        return gems >= amount
    }
}

extension UIColor {
    convenience init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        var rgb: UInt64 = 0
        
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        
        let r = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
        let g = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
        let b = CGFloat(rgb & 0x0000FF) / 255.0
        
        self.init(red: r, green: g, blue: b, alpha: 1.0)
    }
}
