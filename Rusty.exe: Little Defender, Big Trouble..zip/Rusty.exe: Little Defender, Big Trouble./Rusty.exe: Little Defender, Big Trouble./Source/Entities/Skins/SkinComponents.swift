import GameplayKit
import SpriteKit

// MARK: - Visual Component
class SkinVisualComponent: GKComponent {
    private let baseColor: UIColor
    private let glowColor: UIColor
    private let scale: CGFloat
    private var currentParticleEffects: [SKEmitterNode] = []
    private var currentAnimation: SKAction?
    
    init(baseColor: String, glowColor: String, scale: CGFloat) {
        self.baseColor = UIColor(hex: baseColor)
        self.glowColor = UIColor(hex: glowColor)
        self.scale = scale
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyVisuals(to node: SKSpriteNode) {
        // Apply base color and scale
        node.color = baseColor
        node.colorBlendFactor = 1.0
        node.setScale(scale)
        
        // Apply glow effect
        if glowColor != UIColor.clear {
            applyGlowEffect(to: node)
        }
    }
    
    private func applyGlowEffect(to node: SKSpriteNode) {
        let glowNode = SKEffectNode()
        let blur = CIFilter(name: "CIGaussianBlur", parameters: ["inputRadius": 10.0])
        glowNode.filter = blur
        glowNode.shouldRasterize = true
        
        let glowSprite = SKSpriteNode(texture: node.texture)
        glowSprite.color = glowColor
        glowSprite.colorBlendFactor = 1.0
        
        glowNode.addChild(glowSprite)
        node.addChild(glowNode)
    }
    
    func playAnimation(_ type: SkinAnimationType) {
        guard let node = entity?.component(ofType: SKSpriteComponent.self)?.node else { return }
        
        // Stop current animation if any
        node.removeAction(forKey: "currentAnimation")
        
        switch type {
        case .idle:
            playIdleAnimation(on: node)
        case .death:
            playDeathAnimation(on: node)
        }
    }
    
    private func playIdleAnimation(on node: SKNode) {
        // Example idle animation
        let hover = SKAction.sequence([
            SKAction.moveBy(x: 0, y: 5, duration: 1.0),
            SKAction.moveBy(x: 0, y: -5, duration: 1.0)
        ])
        let continuous = SKAction.repeatForever(hover)
        node.run(continuous, withKey: "currentAnimation")
    }
    
    private func playDeathAnimation(on node: SKNode) {
        let fadeOut = SKAction.fadeOut(withDuration: 0.5)
        let scale = SKAction.scale(to: 0, duration: 0.5)
        let group = SKAction.group([fadeOut, scale])
        node.run(group, withKey: "currentAnimation")
    }
}

// MARK: - Effect Component
class SkinEffectComponent: GKComponent {
    private let particleEffect: String?
    private let additionalEffects: [String: Bool]
    private var activeEffects: [String: Any] = [:]
    
    init(particleEffect: String?, additionalEffects: [String: Bool]) {
        self.particleEffect = particleEffect
        self.additionalEffects = additionalEffects
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func applyEffects(to node: SKNode) {
        // Apply main particle effect if any
        if let particleEffect = particleEffect,
           let emitter = SKEmitterNode(fileNamed: particleEffect) {
            node.addChild(emitter)
            activeEffects["mainParticle"] = emitter
        }
        
        // Apply additional effects
        additionalEffects.forEach { effectName, enabled in
            if enabled {
                applyEffect(effectName, to: node)
            }
        }
    }
    
    private func applyEffect(_ effectName: String, to node: SKNode) {
        switch effectName {
        case "motionBlur":
            applyMotionBlur(to: node)
        case "afterImage":
            applyAfterImage(to: node)
        case "environmentalGlow":
            applyEnvironmentalGlow(to: node)
        case "prismaticAura":
            applyPrismaticAura(to: node)
        case "crystalFormation":
            applyCrystalFormation(to: node)
        case "rainbowTrail":
            applyRainbowTrail(to: node)
        default:
            break
        }
    }
    
    private func applyMotionBlur(to node: SKNode) {
        guard let sprite = node as? SKSpriteNode else { return }
        let blur = CIFilter(name: "CIMotionBlur", parameters: ["inputRadius": 10.0])
        let effectNode = SKEffectNode()
        effectNode.filter = blur
        effectNode.addChild(sprite.copy() as! SKNode)
        node.addChild(effectNode)
        activeEffects["motionBlur"] = effectNode
    }
    
    private func applyAfterImage(to node: SKNode) {
        let afterImage = SKAction.sequence([
            SKAction.wait(forDuration: 0.1),
            SKAction.run { [weak self] in
                self?.createAfterImage(for: node)
            }
        ])
        node.run(SKAction.repeatForever(afterImage), withKey: "afterImage")
        activeEffects["afterImage"] = true
    }
    
    private func createAfterImage(for node: SKNode) {
        guard let sprite = node as? SKSpriteNode,
              let texture = sprite.texture else { return }
        
        let ghost = SKSpriteNode(texture: texture)
        ghost.position = sprite.position
        ghost.alpha = 0.5
        ghost.setScale(sprite.xScale)
        
        node.parent?.addChild(ghost)
        
        let fade = SKAction.sequence([
            SKAction.fadeOut(withDuration: 0.5),
            SKAction.removeFromParent()
        ])
        ghost.run(fade)
    }
    
    private func applyEnvironmentalGlow(to node: SKNode) {
        let light = SKLightNode()
        light.categoryBitMask = 1
        light.falloff = 1
        light.ambientColor = .black
        light.lightColor = UIColor(hex: "#ffffff")
        node.addChild(light)
        activeEffects["environmentalGlow"] = light
    }
    
    private func applyPrismaticAura(to node: SKNode) {
        guard let emitter = SKEmitterNode(fileNamed: "PrismaticAura") else { return }
        emitter.targetNode = node
        node.addChild(emitter)
        activeEffects["prismaticAura"] = emitter
    }
    
    private func applyCrystalFormation(to node: SKNode) {
        // Implementation for crystal formation effect
    }
    
    private func applyRainbowTrail(to node: SKNode) {
        // Implementation for rainbow trail effect
    }
    
    func removeEffects() {
        activeEffects.forEach { (key, effect) in
            if let node = effect as? SKNode {
                node.removeFromParent()
            }
        }
        
        if let node = entity?.component(ofType: SKSpriteComponent.self)?.node {
            node.removeAction(forKey: "afterImage")
        }
        
        activeEffects.removeAll()
    }
}

// MARK: - Sound Component
class SkinSoundComponent: GKComponent {
    private let soundEffect: String?
    
    init(soundEffect: String?) {
        self.soundEffect = soundEffect
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func playSound() {
        guard let soundEffect = soundEffect else { return }
        let playSound = SKAction.playSoundFileNamed(soundEffect, waitForCompletion: false)
        entity?.component(ofType: SKSpriteComponent.self)?.node.run(playSound)
    }
}

// MARK: - Supporting Types
enum SkinAnimationType {
    case idle
    case death
}
