import GameplayKit
import SpriteKit

// MARK: - Effect Component
protocol PatchEffectComponentDelegate: AnyObject {
    func effectComponent(_ component: PatchEffectComponent, didUpdateEffect effect: String, value: CGFloat)
    func effectComponent(_ component: PatchEffectComponent, didExpireEffect effect: String)
}

class PatchEffectComponent: GKComponent {
    private struct TemporaryEffect {
        let value: CGFloat
        let duration: TimeInterval
        let startTime: TimeInterval
    }
    
    private var activeEffects: [String: CGFloat] = [:]
    private var temporaryEffects: [String: TemporaryEffect] = [:]
    private let effects: PatchEffects
    
    weak var delegate: PatchEffectComponentDelegate?
    
    init(effects: PatchEffects) {
        self.effects = effects
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(_ deltaTime: TimeInterval) {
        let currentTime = CACurrentMediaTime()
        
        // Update temporary effects
        var expiredEffects: [String] = []
        
        for (effectName, effect) in temporaryEffects {
            let elapsedTime = currentTime - effect.startTime
            if elapsedTime >= effect.duration {
                expiredEffects.append(effectName)
            }
        }
        
        // Remove expired effects
        for effectName in expiredEffects {
            removeTemporaryEffect(effectName)
        }
    }
    
    func applyTemporaryEffect(_ effectName: String, value: CGFloat, duration: TimeInterval) {
        let effect = TemporaryEffect(
            value: value,
            duration: duration,
            startTime: CACurrentMediaTime()
        )
        
        temporaryEffects[effectName] = effect
        activeEffects[effectName] = value
        
        delegate?.effectComponent(self, didUpdateEffect: effectName, value: value)
    }
    
    private func removeTemporaryEffect(_ effectName: String) {
        temporaryEffects.removeValue(forKey: effectName)
        activeEffects.removeValue(forKey: effectName)
        
        delegate?.effectComponent(self, didExpireEffect: effectName)
    }
    
    func applyUpgrade(_ stat: StatType, level: Int) {
        switch stat {
        case .damage:
            if let multiplier = effects.damageMultiplier {
                activeEffects["damageMultiplier"] = multiplier * (1 + 0.2 * CGFloat(level))
            }
        case .fireRate:
            if let multiplier = effects.fireRateMultiplier {
                activeEffects["fireRateMultiplier"] = multiplier * (1 + 0.1 * CGFloat(level))
            }
        // Add other stat upgrades
        default:
            break
        }
    }
    
    func getEffectValue(_ effectName: String) -> CGFloat? {
        return activeEffects[effectName]
    }
    
    func removeEffects() {
        activeEffects.removeAll()
        temporaryEffects.removeAll()
    }
}

// MARK: - Visual Component
class PatchVisualComponent: GKComponent {
    private let visual: PatchVisual
    private var activeParticles: [String: SKEmitterNode] = [:]
    private var colorOverlay: SKSpriteNode?
    
    init(visual: PatchVisual) {
        self.visual = visual
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func playActivationEffect() {
        guard let scene = entity?.component(ofType: GKSKNodeComponent.self)?.node.scene else { return }
        
        // Play activation particle effect
        if let effectNode = SKEmitterNode(fileNamed: visual.activationEffect) {
            effectNode.position = .zero
            scene.addChild(effectNode)
            
            effectNode.run(SKAction.sequence([
                SKAction.wait(forDuration: 2.0),
                SKAction.removeFromParent()
            ]))
        }
        
        // Add continuous particle effect
        if let effectNode = SKEmitterNode(fileNamed: visual.particleEffect) {
            entity?.component(ofType: GKSKNodeComponent.self)?.node.addChild(effectNode)
            activeParticles["main"] = effectNode
        }
        
        // Apply color overlay
        applyColorOverlay()
        
        // Play sound effect
        scene.run(SKAction.playSoundFileNamed(visual.soundEffect, waitForCompletion: false))
    }
    
    private func applyColorOverlay() {
        guard let node = entity?.component(ofType: GKSKNodeComponent.self)?.node else { return }
        
        let overlay = SKSpriteNode(color: UIColor(hex: visual.color), size: node.frame.size)
        overlay.alpha = visual.opacity
        overlay.zPosition = 1
        node.addChild(overlay)
        colorOverlay = overlay
    }
    
    func playCriticalEffect() {
        guard let scene = entity?.component(ofType: GKSKNodeComponent.self)?.node.scene else { return }
        
        if let effectNode = SKEmitterNode(fileNamed: "CriticalHit") {
            effectNode.position = .zero
            scene.addChild(effectNode)
            
            effectNode.run(SKAction.sequence([
                SKAction.wait(forDuration: 0.5),
                SKAction.removeFromParent()
            ]))
        }
    }
    
    func removeVisualEffects() {
        // Remove particle effects
        activeParticles.values.forEach { particle in
            particle.run(SKAction.sequence([
                SKAction.fadeOut(withDuration: 0.5),
                SKAction.removeFromParent()
            ]))
        }
        activeParticles.removeAll()
        
        // Remove color overlay
        colorOverlay?.run(SKAction.sequence([
            SKAction.fadeOut(withDuration: 0.5),
            SKAction.removeFromParent()
        ]))
        colorOverlay = nil
    }
}

// MARK: - State Component
class PatchStateComponent: GKComponent {
    enum State {
        case inactive
        case active
        case cooldown
    }
    
    private(set) var currentState: State = .inactive
    private var cooldownEndTime: TimeInterval = 0
    
    func setState(_ state: State) {
        currentState = state
        
        if state == .cooldown {
            if let patch = entity as? SoftwarePatch,
               let cooldown = patch.getEffects().cooldown {
                cooldownEndTime = CACurrentMediaTime() + cooldown
            }
        }
    }
    
    func canActivate() -> Bool {
        if currentState == .cooldown {
            return CACurrentMediaTime() >= cooldownEndTime
        }
        return currentState == .inactive
    }
    
    func getRemainingCooldown() -> TimeInterval {
        if currentState == .cooldown {
            let remaining = cooldownEndTime - CACurrentMediaTime()
            return max(0, remaining)
        }
        return 0
    }
}

// MARK: - Sound Component
class PatchSoundComponent: GKComponent {
    private var activeLoopedSounds: [String: SKAudioNode] = [:]
    
    func playSound(_ name: String, looped: Bool = false) {
        guard let scene = entity?.component(ofType: GKSKNodeComponent.self)?.node.scene else { return }
        
        if looped {
            let audioNode = SKAudioNode(fileNamed: name)
            scene.addChild(audioNode)
            activeLoopedSounds[name] = audioNode
        } else {
            scene.run(SKAction.playSoundFileNamed(name, waitForCompletion: false))
        }
    }
    
    func stopSound(_ name: String) {
        if let audioNode = activeLoopedSounds[name] {
            audioNode.run(SKAction.sequence([
                SKAction.fadeOut(withDuration: 0.5),
                SKAction.removeFromParent()
            ]))
            activeLoopedSounds.removeValue(forKey: name)
        }
    }
    
    func stopAllSounds() {
        activeLoopedSounds.forEach { _, audioNode in
            audioNode.run(SKAction.removeFromParent())
        }
        activeLoopedSounds.removeAll()
    }
}

// MARK: - Extensions
extension UIColor {
    convenience init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        var rgb: UInt64 = 0
        
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        
        let r = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
        let g = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
        let b = CGFloat(rgb & 0x0000FF) / 255.0
        
        self.init(red: r, green: g, blue: b, alpha: 1.0)
    }
}
