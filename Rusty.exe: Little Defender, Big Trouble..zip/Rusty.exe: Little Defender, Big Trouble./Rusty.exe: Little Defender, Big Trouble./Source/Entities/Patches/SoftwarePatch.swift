import GameplayKit

// MARK: - Supporting Structures
struct PatchEffects: Codable {
    var damageMultiplier: CGFloat?
    var fireRateMultiplier: CGFloat?
    var healthRestore: CGFloat?
    var duration: PatchDuration
    var immuneToDamage: Bool?
    var damageVulnerability: CGFloat?
    var damageConversion: CGFloat?
    var shieldRegeneration: Bool?
    var criticalChance: CGFloat?
    var criticalMultiplier: CGFloat?
    var timeScale: CGFloat?
    var damagePerHealthLost: CGFloat?
    var maxBonus: CGFloat?
    var shotInterval: Int?
    var extraProjectiles: Int?
    var resistancePerHit: CGFloat?
    var maxResistance: CGFloat?
    var healthThreshold: CGFloat?
    var cooldown: TimeInterval?
}

enum PatchDuration: Codable {
    enum DurationType: String, Codable {
        case timed, waveEnd, permanent
    }

    enum CodingKeys: String, CodingKey {
        case type, value
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .timed(let seconds):
            try container.encode(DurationType.timed, forKey: .type)
            try container.encode(seconds, forKey: .value)
        case .waveEnd:
            try container.encode(DurationType.waveEnd, forKey: .type)
        case .permanent:
            try container.encode(DurationType.permanent, forKey: .type)
        }
    }

    case timed(seconds: TimeInterval)
    case waveEnd
    case permanent

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let seconds = try? container.decode(TimeInterval.self) {
            self = .timed(seconds: seconds)
        } else if let string = try? container.decode(String.self) {
            switch string {
            case "waveEnd": self = .waveEnd
            case "permanent": self = .permanent
            default: throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid duration type")
            }
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Unable to decode duration")
        }
    }
}

struct PatchVisual: Codable {
    let activationEffect: String?
    let particleEffect: String?
    let soundEffect: String?
    let hitEffect: String?
}

// MARK: - Main Class
class SoftwarePatch: GKEntity {
    private let id: String
    private let name: String
    private let patchDescription: String
    private let type: PatchType
    private let rarity: String
    private let effects: PatchEffects
    private let visual: PatchVisual

    private var isActive: Bool = false
    private var lastActivationTime: TimeInterval = 0
    private var accumulatedResistances: [DamageType: CGFloat] = [:]

    weak var delegate: SoftwarePatchDelegate?

    private lazy var effectComponent: PatchEffectComponent = {
        return PatchEffectComponent(effects: effects)
    }()

    private lazy var visualComponent: PatchVisualComponent = {
        return PatchVisualComponent(visual: visual)
    }()

    init(id: String,
         name: String,
         patchDescription: String,
         type: PatchType,
         rarity: String,
         effects: PatchEffects,
         visual: PatchVisual) {

        self.id = id
        self.name = name
        self.patchDescription = patchDescription
        self.type = type
        self.rarity = rarity
        self.effects = effects
        self.visual = visual

        super.init()

        addComponent(effectComponent)
        addComponent(visualComponent)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func tryActivate(trigger: TriggerCondition) -> Bool {
        guard !isActive || type == .passive else { return false }

        if let cooldown = effects.cooldown {
            let currentTime = CACurrentMediaTime()
            if currentTime - lastActivationTime < cooldown {
                return false
            }
        }

        switch type {
        case .deathTrigger:
            if case .death = trigger {
                activate()
                return true
            }
        case .healthTrigger:
            if case .healthThreshold(let percentage) = trigger,
               let threshold = effects.healthThreshold,
               percentage <= threshold {
                activate()
                return true
            }
        case .passive:
            activate()
            return true
        }

        return false
    }

    private func activate() {
        isActive = true
        lastActivationTime = CACurrentMediaTime()

        visualComponent.playActivationEffect()
        delegate?.patch(self, didActivateWithEffects: effects)

        switch effects.duration {
        case .timed(let seconds):
            DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in
                self?.deactivate()
            }
        case .waveEnd: break
        case .permanent: break
        }
    }

    func deactivate() {
        isActive = false
        delegate?.patchDidDeactivate(self)
    }

    func modifyDamage(_ damage: CGFloat) -> CGFloat {
        guard isActive else { return damage }
        var modified = damage

        if let multiplier = effects.damageMultiplier {
            modified *= multiplier
        }
        if let critChance = effects.criticalChance,
           let critMultiplier = effects.criticalMultiplier,
           Double.random(in: 0...1) < Double(critChance) {
            modified *= critMultiplier
            visualComponent.playCriticalEffect()
        }
        return modified
    }

    func modifyFireRate(_ rate: CGFloat) -> CGFloat {
        guard isActive else { return rate }
        return rate * (effects.fireRateMultiplier ?? 1.0)
    }

    func handleDamageTaken(_ damage: CGFloat, type: DamageType) {
        if let conversion = effects.damageConversion,
           effects.shieldRegeneration == true {
            let energyGained = damage * conversion
            delegate?.patch(self, didConvertDamageToEnergy: energyGained)
        }

        if let resistance = effects.resistancePerHit {
            let current = accumulatedResistances[type] ?? 0
            accumulatedResistances[type] = min(current + resistance, effects.maxResistance ?? 1.0)
        }
    }

    // MARK: - Getters
    func getId() -> String { return id }
    func getName() -> String { return name }
    func getType() -> PatchType { return type }
    func getRarity() -> String { return rarity }
    func isCurrentlyActive() -> Bool { return isActive }
}

// MARK: - Supporting Types
enum PatchType: String, Codable {
    case deathTrigger
    case healthTrigger
    case passive
}

enum TriggerCondition: Codable {
    case death
    case healthThreshold(percentage: CGFloat)
}

enum DamageType: String, Codable, Hashable {
    case normal
    case energy
    case explosive
    case temporal
}

protocol SoftwarePatchDelegate: AnyObject {
    func patch(_ patch: SoftwarePatch, didActivateWithEffects effects: PatchEffects)
    func patchDidDeactivate(_ patch: SoftwarePatch)
    func patch(_ patch: SoftwarePatch, didConvertDamageToEnergy energy: CGFloat)
}
