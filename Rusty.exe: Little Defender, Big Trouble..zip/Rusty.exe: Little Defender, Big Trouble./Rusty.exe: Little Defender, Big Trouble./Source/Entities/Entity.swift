// Entity.swift
import Foundation

class Entity {
    private var components: [String: Component] = [:]

    func addComponent<T: Component>(_ component: T) {
        let key = String(describing: T.self)
        components[key] = component
    }

    func getComponent<T: Component>(ofType type: T.Type) -> T? {
        let key = String(describing: T.self)
        return components[key] as? T
    }
}
