//
//  Weapon.swift
//  Rusty.exe: Little Defender, Big Trouble.
//

import GameplayKit
import Foundation

// Uses enums and types from Constants.swift:
// - WeaponType
// - ProjectileBehavior
// - ProjectileType
// - Rarity
// - StatType
// - CurrencyRequirement
// - WeaponStats and UpgradeLevel are retained with local customization

struct WeaponStats: Codable {
    var damage: CGFloat
    var rateOfFire: CGFloat?
    var projectilesPerShot: Int?
    var spread: CGFloat?
    var projectileSpeed: CGFloat?
    var chargeTime: CGFloat?
    var range: CGFloat?
    var energyCost: CGFloat?

    func value(forKey key: String) -> Any? {
        switch key {
        case "damage": return damage
        case "rateOfFire": return rateOfFire
        case "projectilesPerShot": return projectilesPerShot
        case "spread": return spread
        case "projectileSpeed": return projectileSpeed
        case "chargeTime": return chargeTime
        case "range": return range
        case "energyCost": return energyCost
        default: return nil
        }
    }

    mutating func setValue(_ value: CGFloat, forKey key: String) {
        switch key {
        case "damage": damage = value
        case "rateOfFire": rateOfFire = value
        case "spread": spread = value
        case "projectileSpeed": projectileSpeed = value
        case "chargeTime": chargeTime = value
        case "range": range = value
        case "energyCost": energyCost = value
        default: break
        }
    }
}

struct UpgradeLevel: Codable {
    let requirement: CurrencyRequirement
    let value: CGFloat
    let description: String?
}

struct WeaponInfo: Codable {
    let id: String
    let name: String
    let type: WeaponType
    let projectileBehavior: ProjectileBehavior
    let projectileType: ProjectileType
    let weaponDescription: String
    let baseStats: WeaponStats
    let upgrades: [String: [UpgradeLevel]]
    let premium: Bool?
}

protocol WeaponDelegate: AnyObject {
    func weapon(_ weapon: Weapon, didFireProjectile projectile: GKEntity)
    func weapon(_ weapon: Weapon, didUpdateStats stats: WeaponStats)
}

class Weapon: GKEntity {
    private let id: String
    private let name: String
    private let type: WeaponType
    private let projectileBehavior: ProjectileBehavior
    private let projectileType: ProjectileType
    private let weaponDescription: String
    private let rarity: Rarity
    private var stats: WeaponStats
    private var upgradeLevels: [StatType: Int] = [:]
    private var lastFireTime: TimeInterval = 0
    private let premium: Bool

    weak var delegate: WeaponDelegate?

    private lazy var upgradeComponent: UpgradeComponent = {
        UpgradeComponent(upgrades: upgrades)
    }()

    private lazy var projectileComponent: ProjectileComponent = {
        ProjectileComponent(behavior: projectileBehavior, type: projectileType)
    }()

    private let upgrades: [StatType: [UpgradeLevel]]

    init(id: String,
         name: String,
         type: WeaponType,
         projectileBehavior: ProjectileBehavior,
         projectileType: ProjectileType,
         weaponDescription: String,
         rarity: Rarity,
         baseStats: WeaponStats,
         upgrades: [StatType: [UpgradeLevel]],
         premium: Bool = false) {

        self.id = id
        self.name = name
        self.type = type
        self.projectileBehavior = projectileBehavior
        self.projectileType = projectileType
        self.weaponDescription = weaponDescription
        self.rarity = rarity
        self.stats = baseStats
        self.premium = premium
        self.upgrades = upgrades

        super.init()

        addComponent(upgradeComponent)
        addComponent(projectileComponent)

        upgrades.keys.forEach { stat in
            upgradeLevels[stat] = 0
        }
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func canFire(currentTime: TimeInterval) -> Bool {
        guard let rateOfFire = stats.rateOfFire else { return true }
        return currentTime - lastFireTime >= 1.0 / rateOfFire
    }

    func fire(currentTime: TimeInterval) -> [GKEntity] {
        guard canFire(currentTime: currentTime) else { return [] }
        lastFireTime = currentTime
        return createProjectiles()
    }

    private func createProjectiles() -> [GKEntity] {
        let count = stats.projectilesPerShot ?? 1
        var projectiles: [GKEntity] = []
        for _ in 0..<count {
            if let projectile = createProjectile() {
                projectiles.append(projectile)
                delegate?.weapon(self, didFireProjectile: projectile)
            }
        }
        return projectiles
    }

    private func createProjectile() -> GKEntity? {
        return projectileComponent.createProjectile(with: stats)
    }

    func canUpgrade(_ stat: StatType) -> Bool {
        let currentLevel = upgradeLevels[stat] ?? 0
        return currentLevel < (upgradeComponent.getUpgradeLevels(for: stat)?.count ?? 0)
    }

    func getUpgradeCost(_ stat: StatType) -> CurrencyRequirement? {
        let currentLevel = upgradeLevels[stat] ?? 0
        return upgradeComponent.getUpgradeCost(for: stat, at: currentLevel)
    }

    func upgrade(_ stat: StatType) -> Bool {
        guard canUpgrade(stat) else { return false }
        let currentLevel = upgradeLevels[stat] ?? 0
        let nextLevel = currentLevel + 1
        if let upgradeValue = upgradeComponent.getUpgradeValue(for: stat, at: currentLevel) {
            upgradeLevels[stat] = nextLevel
            stats.setValue(upgradeValue, forKey: stat.rawValue)
            delegate?.weapon(self, didUpdateStats: stats)
            return true
        }
        return false
    }

    func getStat(_ stat: StatType) -> CGFloat {
        return stats.value(forKey: stat.rawValue) as? CGFloat ?? 0
    }

    func getId() -> String { return id }
    func getName() -> String { return name }
    func getType() -> WeaponType { return type }
    func isPremium() -> Bool { return premium }
}

class UpgradeComponent: GKComponent {
    private let upgrades: [StatType: [UpgradeLevel]]

    init(upgrades: [StatType: [UpgradeLevel]]) {
        self.upgrades = upgrades
        super.init()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func getUpgradeLevels(for stat: StatType) -> [UpgradeLevel]? {
        return upgrades[stat]
    }

    func getUpgradeCost(for stat: StatType, at level: Int) -> CurrencyRequirement? {
        return upgrades[stat]?[level].requirement
    }

    func getUpgradeValue(for stat: StatType, at level: Int) -> CGFloat? {
        return upgrades[stat]?[level].value
    }
}

class ProjectileComponent: GKComponent {
    private let behavior: ProjectileBehavior
    private let type: ProjectileType

    init(behavior: ProjectileBehavior, type: ProjectileType) {
        self.behavior = behavior
        self.type = type
        super.init()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func createProjectile(with stats: WeaponStats) -> GKEntity? {
        // Custom implementation goes here
        return nil
    }
}
