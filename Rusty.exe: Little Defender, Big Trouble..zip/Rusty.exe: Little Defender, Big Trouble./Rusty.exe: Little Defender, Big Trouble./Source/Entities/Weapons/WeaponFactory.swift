import GameplayKit

class WeaponFactory {
    // MARK: - Properties
    private static var weaponsData: [String: Any]?

    // MARK: - Initialization
    static func initialize() {
        guard let url = Bundle.main.url(forResource: "weapons", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
            print("Failed to load weapons data")
            return
        }

        weaponsData = json["weapons"] as? [String: Any]
    }

    // MARK: - Weapon Creation
    static func createWeapon(weaponId: String) -> Weapon? {
        guard let weaponData = weaponsData?[weaponId] as? [String: Any] else {
            print("Weapon data not found for ID: \(weaponId)")
            return nil
        }

        do {
            // Convert weapon data to JSON data
            let jsonData = try JSONSerialization.data(withJSONObject: weaponData)

            // Decode the weapon data using the canonical WeaponInfo
            let decoder = JSONDecoder()
            let weaponInfo = try decoder.decode(WeaponInfo.self, from: jsonData)

            // Create the weapon
            return Weapon(
                id: weaponId,
                name: weaponInfo.name,
                type: weaponInfo.type,
                projectileBehavior: weaponInfo.projectileBehavior,
                projectileType: weaponInfo.projectileType,
                weaponDescription: weaponInfo.weaponDescription,
                baseStats: weaponInfo.baseStats,
                upgrades: weaponInfo.upgrades,
                premium: weaponInfo.premium ?? false
            )
        } catch {
            print("Error creating weapon: \(error)")
            return nil
        }
    }

    // MARK: - Helper Functions
    static func getAllWeaponIds() -> [String] {
        return weaponsData?.keys.map { $0 } ?? []
    }

    static func getUnlockCost(weaponId: String) -> WeaponCost? {
        guard let weaponData = weaponsData?[weaponId] as? [String: Any],
              let unlockCostData = weaponData["unlockCost"] as? [String: Any] else {
            return nil
        }

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: unlockCostData)
            return try JSONDecoder().decode(WeaponCost.self, from: jsonData)
        } catch {
            print("Error getting unlock cost: \(error)")
            return nil
        }
    }
}
