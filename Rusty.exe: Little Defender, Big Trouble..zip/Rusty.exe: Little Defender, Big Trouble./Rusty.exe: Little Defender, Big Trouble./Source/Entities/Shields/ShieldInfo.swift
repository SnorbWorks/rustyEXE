// ShieldInfo.swift

import Foundation

struct ShieldInfo: Codable {
    let id: String
    let name: String
    let description: String
    let maxStrength: Int
    let rechargeRate: Int
    let rechargeDelay: TimeInterval
    let resistance: Float

    // Future extension (e.g. visual style or special traits)
    // let color: String
    // let visualEffect: String

    init(
        id: String,
        name: String,
        description: String,
        maxStrength: Int,
        rechargeRate: Int,
        rechargeDelay: TimeInterval,
        resistance: Float
    ) {
        self.id = id
        self.name = name
        self.description = description
        self.maxStrength = maxStrength
        self.rechargeRate = rechargeRate
        self.rechargeDelay = rechargeDelay
        self.resistance = resistance
    }
}
