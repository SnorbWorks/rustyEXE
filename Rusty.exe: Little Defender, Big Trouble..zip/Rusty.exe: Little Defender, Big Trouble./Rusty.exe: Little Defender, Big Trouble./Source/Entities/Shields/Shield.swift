import GameplayKit
import SpriteKit

protocol ShieldDelegate: AnyObject {
    func shield(_ shield: Shield, didTakeDamage damage: CGFloat)
    func shieldDidDestroy(_ shield: Shield)
    func shield(_ shield: Shield, didApplyEffectTo entity: GKEntity)
}

class Shield: GKEntity {
    // MARK: - Properties
    private let id: String
    private let name: String
    private let shieldDescription: String  // Renamed from 'description' to avoid conflict
    private let type: ShieldType
    private let behavior: ShieldBehavior
    private let rarity: Rarity
    private var stats: ShieldStats
    private let visual: VisualEffects
    private var currentHealth: CGFloat
    private var remainingDuration: CGFloat
    private var position: Vector2
    private var active: Bool = false
    private var deploying: Bool = false
    private var deployProgress: CGFloat = 0
    private let unlockRequirement: CurrencyRequirement
    private var upgradeLevels: [StatType: Int] = [:]
    
    weak var delegate: ShieldDelegate?
    
    // MARK: - Components
    private lazy var shieldBehaviorComponent: ShieldBehaviorComponent = {
        let component = ShieldBehaviorComponent(behavior: behavior, stats: stats)
        return component
    }()
    
    private lazy var visualComponent: ShieldVisualComponent = {
        let component = ShieldVisualComponent(effects: visual)
        return component
    }()
    
    // MARK: - Initialization
    init(id: String,
         name: String,
         shieldDescription: String, // updated parameter
         type: ShieldType,
         behavior: ShieldBehavior,
         rarity: Rarity,
         stats: ShieldStats,
         visual: VisualEffects,
         unlockRequirement: CurrencyRequirement) {
        
        self.id = id
        self.name = name
        self.shieldDescription = shieldDescription
        self.type = type
        self.behavior = behavior
        self.rarity = rarity
        self.stats = stats
        self.visual = visual
        self.unlockRequirement = unlockRequirement
        self.currentHealth = stats.health
        self.remainingDuration = stats.duration
        self.position = Vector2(x: 0, y: 0)
        
        super.init()
        
        addComponent(shieldBehaviorComponent)
        addComponent(visualComponent)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Shield Functions
    func update(deltaTime: TimeInterval) {
        if deploying {
            updateDeployment(deltaTime: deltaTime)
        }
        
        guard active else { return }
        
        remainingDuration -= CGFloat(deltaTime)
        if remainingDuration <= 0 {
            destroy()
            return
        }
        
        if let regeneration = stats.regenerationRate, regeneration > 0 {
            regenerateHealth(amount: regeneration * CGFloat(deltaTime))
        }
        
        shieldBehaviorComponent.update(deltaTime: deltaTime)
    }
    
    func deploy(at position: Vector2) {
        self.position = position
        deploying = true
        deployProgress = 0
        visualComponent.playEffect(.deploy) // If 'deploy' is an enum value, ensure .deploy is scoped correctly
    }
    
    private func updateDeployment(deltaTime: TimeInterval) {
        deployProgress += CGFloat(deltaTime) / stats.deployTime
        if deployProgress >= 1 {
            deploying = false
            active = true
            visualComponent.playEffect(.active)
        }
    }
    
    func handleCollision(with entity: GKEntity) {
        guard active else { return }
        shieldBehaviorComponent.handleCollision(with: entity)
        delegate?.shield(self, didApplyEffectTo: entity)
    }
    
    func takeDamage(_ amount: CGFloat) {
        currentHealth -= amount
        visualComponent.playEffect(.damage)
        delegate?.shield(self, didTakeDamage: amount)
        
        if currentHealth <= 0 {
            destroy()
        }
    }
    
    private func regenerateHealth(amount: CGFloat) {
        currentHealth = min(currentHealth + amount, stats.health)
    }
    
    func destroy() {
        active = false
        visualComponent.playEffect(.destroy)
        delegate?.shieldDidDestroy(self)
    }
    
    // MARK: - Upgrade Functions
    func canUpgrade(_ stat: StatType) -> Bool {
        let currentLevel = upgradeLevels[stat] ?? 0
        return currentLevel < getMaxUpgradeLevel(for: stat)
    }
    
    func getUpgradeRequirement(_ stat: StatType, level: Int) -> CurrencyRequirement? {
        return nil
    }
    
    func upgrade(_ stat: StatType) -> Bool {
        guard canUpgrade(stat) else { return false }
        let currentLevel = upgradeLevels[stat] ?? 0
        upgradeLevels[stat] = currentLevel + 1
        applyUpgrade(stat, level: currentLevel + 1)
        return true
    }
    
    private func applyUpgrade(_ stat: StatType, level: Int) {
        // implementation here
    }
    
    private func getMaxUpgradeLevel(for stat: StatType) -> Int {
        return 5
    }
    
    // MARK: - Getters
    func getId() -> String { return id }
    func getName() -> String { return name }
    func getType() -> ShieldType { return type }
    func getBehavior() -> ShieldBehavior { return behavior }
    func getRarity() -> Rarity { return rarity }
    func getPosition() -> Vector2 { return position }
    func getRadius() -> CGFloat { return stats.radius }
    func getCurrentHealth() -> CGFloat { return currentHealth }
    func getMaxHealth() -> CGFloat { return stats.health }
    func getRemainingDuration() -> CGFloat { return remainingDuration }
    func isActive() -> Bool { return active }
    func getUnlockRequirement() -> CurrencyRequirement { return unlockRequirement }
    
    func getCurrentUpgradeLevel(_ stat: StatType) -> Int {
        return upgradeLevels[stat] ?? 0
    }
    
    func getAllUpgradeLevels() -> [String: Int] {
        return Dictionary(uniqueKeysWithValues: upgradeLevels.map {
            (stat, level) in (stat.rawValue, level)
        })
    }
}
