// ShieldFactory.swift

import Foundation

class ShieldFactory {
    static let shared = ShieldFactory()
    private(set) var shields: [ShieldInfo] = []

    private init() {
        loadShields()
    }

    private func loadShields() {
        guard let url = Bundle.main.url(forResource: "shields", withExtension: "json") else {
            print("❌ shields.json not found.")
            return
        }

        do {
            let data = try Data(contentsOf: url)
            let wrapper = try JSONDecoder().decode(ShieldListWrapper.self, from: data)

            self.shields = wrapper.shields.map { key, value in
                var modified = value
                modified.id = key
                return modified
            }

            print("✅ Loaded \(shields.count) shields.")
        } catch {
            print("❌ Failed to load shields.json:", error)
        }
    }

    func getAllShields() -> [ShieldInfo] {
        return shields
    }

    func getShield(byId id: String) -> ShieldInfo? {
        return shields.first(where: { $0.id == id })
    }

    static func getUnlockCost(shieldId: String) -> CurrencyRequirement? {
        guard let url = Bundle.main.url(forResource: "shield_costs", withExtension: "json") else {
            print("❌ shield_costs.json not found.")
            return nil
        }

        do {
            let data = try Data(contentsOf: url)
            let costDict = try JSONDecoder().decode([String: CurrencyRequirement].self, from: data)
            return costDict[shieldId]
        } catch {
            print("❌ Failed to load shield_costs.json:", error)
            return nil
        }
    }
}

// MARK: - Wrapper for JSON dictionary
private struct ShieldListWrapper: Codable {
    let shields: [String: ShieldInfo]
}
