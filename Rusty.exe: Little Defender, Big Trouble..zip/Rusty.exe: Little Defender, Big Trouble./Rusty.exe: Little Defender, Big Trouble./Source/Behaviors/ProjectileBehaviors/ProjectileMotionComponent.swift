import GameplayKit

class ProjectileMotionComponent: GKComponent {
    private let type: String
    private let behavior: String
    private var position: Vector2
    private var velocity: Vector2
    private var lifetime: TimeInterval = 0
    private let config: ProjectileConfig

    init(type: String,
         behavior: String,
         startPos: Vector2,
         direction: Vector2,
         config: ProjectileConfig) {
        self.type = type
        self.behavior = behavior
        self.position = startPos
        self.velocity = direction.normalize().multiply(config.speed)
        self.config = config
        super.init()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func update(deltaTime: TimeInterval) {
        super.update(deltaTime: deltaTime)

        lifetime += deltaTime

        switch behavior {
        case "straight":
            updateStraight(deltaTime: deltaTime)
        case "wave":
            updateWave(deltaTime: deltaTime)
        case "spiral":
            updateSpiral(deltaTime: deltaTime)
        case "homing":
            updateHoming(deltaTime: deltaTime)
        default:
            updateStraight(deltaTime: deltaTime)
        }
    }

    private func updateStraight(deltaTime: TimeInterval) {
        let displacement = velocity.multiply(CGFloat(deltaTime))
        position = position.add(displacement)
    }

    private func updateWave(deltaTime: TimeInterval) {
        let amplitude = config.waveAmplitude ?? 10.0
        let frequency = config.waveFrequency ?? 2.0

        let forwardMove = velocity.multiply(CGFloat(deltaTime))
        let waveOffset = Vector2(x: 0, y: amplitude * sin(CGFloat(lifetime) * frequency * 2 * .pi))
        position = position.add(forwardMove).add(waveOffset)
    }

    private func updateSpiral(deltaTime: TimeInterval) {
        let spiralRadius = config.spiralRadius ?? 30.0
        let spiralSpeed = config.spiralSpeed ?? 5.0

        let forwardMove = velocity.multiply(CGFloat(deltaTime))
        let angle = spiralSpeed * CGFloat(lifetime)
        let spiral = Vector2(
            x: spiralRadius * cos(angle),
            y: spiralRadius * sin(angle)
        )

        position = position.add(forwardMove).add(spiral)
    }

    private func updateHoming(deltaTime: TimeInterval) {
        guard let targetPos = findNearestTarget() else {
            updateStraight(deltaTime: deltaTime)
            return
        }

        let toTarget = targetPos.subtract(position).normalize()
        let turnRate = config.turnRate ?? 2.0
        let currentDir = velocity.normalize()
        let newDir = currentDir.lerp(to: toTarget, t: CGFloat(deltaTime) * turnRate).normalize()

        velocity = newDir.multiply(config.speed)
        let displacement = velocity.multiply(CGFloat(deltaTime))
        position = position.add(displacement)
    }

    private func findNearestTarget() -> Vector2? {
        // Placeholder target logic
        // In a real game, this would search the scene or manager
        return nil
    }

    func isExpired() -> Bool {
        if let range = config.range {
            return lifetime * Double(config.speed) > Double(range)
        }
        return lifetime > (config.duration ?? 5.0)
    }

    func getPosition() -> Vector2 {
        return position
    }
}

struct ProjectileConfig {
    let speed: CGFloat
    let range: CGFloat?
    let duration: TimeInterval?
    let turnRate: CGFloat?
    let waveAmplitude: CGFloat?
    let waveFrequency: CGFloat?
    let spiralRadius: CGFloat?
    let spiralSpeed: CGFloat?
}
