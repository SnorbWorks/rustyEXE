//
//  Rusty_exe__Little_Defender__Big_Trouble_Tests.swift
//  Rusty.exe: Little Defender, Big Trouble.Tests
//
//  Created by shawn duckett on 5/29/25.
//

import Testing
@testable import Rusty_exe__Little_Defender__Big_Trouble_

struct Rusty_exe__Little_Defender__Big_Trouble_Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
